import argparse
import importlib.metadata
import importlib.util
import inspect
import json
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument("--output", type=Path, required=True)
a = p.parse_args()
import torch
import flashinfer

result = {"torch": torch.__version__, "cuda": torch.version.cuda,
          "capability": torch.cuda.get_device_capability(),
          "gpu": torch.cuda.get_device_name(), "flashinfer": flashinfer.__version__}
result["packages"] = {}
for package in ("b12x", "triton", "nvidia-cutlass-dsl", "vllm", "safetensors", "flashinfer-python"):
    try:
        result["packages"][package] = importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        result["packages"][package] = None
result["paths"] = {name: str(importlib.util.find_spec(name)) for name in ("b12x", "cutlass", "triton")}
result["sources"] = {}
for name in ("b12x", "flashinfer", "vllm"):
    directory = Path("/repo/3pty") / name
    result["sources"][name] = {"exists": directory.is_dir(), "files": len(list(directory.glob("*")))}
result["snapshots"] = [str(path) for path in Path("/hf").glob("models--*/snapshots/*") if "Qwen" in str(path)]
from flashinfer import nvfp4_quantize
from flashinfer.gemm import mm_fp4
result["signatures"] = {"nvfp4_quantize": str(inspect.signature(nvfp4_quantize)), "mm_fp4": str(inspect.signature(mm_fp4))}
(a.output / "inventory.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
