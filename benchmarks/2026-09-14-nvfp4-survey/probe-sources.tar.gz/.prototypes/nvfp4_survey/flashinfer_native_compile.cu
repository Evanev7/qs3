// Isolated AOT compile probe: no PyTorch/TVM/Python runtime dependencies.
#include "flashinfer/gemm/cutlass_gemm_configs.h"
#include "flashinfer/gemm/fp4_gemm_template_sm120.h"

namespace flashinfer::gemm {
INSTANTIATE_FP4_GEMM_KERNEL_LAUNCHER(__nv_bfloat16, 128, 32, 128, 1, 1, 1, _1SM, true)
INSTANTIATE_FP4_GEMM_KERNEL_LAUNCHER(__nv_bfloat16, 128, 64, 128, 1, 1, 1, _1SM, true)
}

// Query workspace with null a/b/out, then pass caller-owned workspace.
extern "C" size_t qs3_probe_fp4(void* out, const void* a, const void* b,
                                const void* as, const void* bs, const float* alpha,
                                int m, int n, int k, void* workspace, size_t capacity,
                                cudaStream_t stream, int tactic) {
    using namespace flashinfer::gemm;
    bool stream_k = tactic % 2;
    CutlassGemmConfig config(tactic < 2 ? CutlassTileConfigSM120::CtaShape128x32x64B
                                      : CutlassTileConfigSM120::CtaShape128x64x64B,
                            MainloopScheduleType::AUTO, EpilogueScheduleType::AUTO,
                            ClusterShape::ClusterShape_1x1x1, true, stream_k);
    if (tactic >= 2) {
        if (stream_k) {
            return genericFp4GemmKernelLauncherStreamK<__nv_bfloat16, cute::Int<128>, cute::Int<64>,
                cute::Int<128>, cute::Int<1>, cute::Int<1>, cute::Int<1>, _1SM, true>(
                    out, a, b, as, bs, alpha, m, n, k, 1, config,
                    static_cast<char*>(workspace), capacity, stream, nullptr);
        }
        return genericFp4GemmKernelLauncher<__nv_bfloat16, cute::Int<128>, cute::Int<64>,
            cute::Int<128>, cute::Int<1>, cute::Int<1>, cute::Int<1>, _1SM, true>(
                out, a, b, as, bs, alpha, m, n, k, 1, config,
                static_cast<char*>(workspace), capacity, stream, nullptr);
    }
    if (stream_k) {
        return genericFp4GemmKernelLauncherStreamK<__nv_bfloat16, cute::Int<128>, cute::Int<32>,
            cute::Int<128>, cute::Int<1>, cute::Int<1>, cute::Int<1>, _1SM, true>(
                out, a, b, as, bs, alpha, m, n, k, 1, config,
                static_cast<char*>(workspace), capacity, stream, nullptr);
    }
    return genericFp4GemmKernelLauncher<__nv_bfloat16, cute::Int<128>, cute::Int<32>,
        cute::Int<128>, cute::Int<1>, cute::Int<1>, cute::Int<1>, _1SM, true>(
            out, a, b, as, bs, alpha, m, n, k, 1, config,
            static_cast<char*>(workspace), capacity, stream, nullptr);
}
