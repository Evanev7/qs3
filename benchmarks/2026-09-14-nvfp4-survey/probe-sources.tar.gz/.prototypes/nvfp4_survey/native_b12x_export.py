"""Qualify real b12x CuTe exported .o + generated host launchers, no JIT calls."""
import argparse
import ctypes
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import torch
from common import metrics
from native_marlin import fixture

def main():
    here=Path(__file__).resolve().parent;root=here.parents[1]
    ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,required=True)
    ap.add_argument("--exports",type=Path,default=root/".prototypes/out/nvfp4-b12x_probe-20260914T191625Z-alar0p8x/exports")
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    runtime=None
    for distribution in importlib.metadata.distributions():
        for file in distribution.files or []:
            if str(file).endswith("libcuda_dialect_runtime_static.a"):
                runtime=Path(distribution.locate_file(file)).resolve();break
        if runtime:break
    if runtime is None:raise RuntimeError("CuTe static CUDA dialect runtime archive was not found in installed wheel metadata")
    objects=[args.exports/"qs3_b12x_densegemmlaunch_0.o",args.exports/"qs3_b12x_densesplitkreduce_1.o"]
    library=args.output/"b12x_export_native.so"
    command=["nvcc","-std=c++17","-O3","-gencode=arch=compute_121a,code=sm_121a","-shared","-Xcompiler=-fPIC",
             "-I"+str(args.exports),str(here/"native_b12x_export.cu"),*[str(p) for p in objects],str(runtime),"-lcuda","-o",str(library)]
    (args.output/"compile_command.json").write_text(json.dumps(command,indent=2)+"\n")
    (args.output/"export_inputs.json").write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*objects,runtime]},indent=2)+"\n")
    subprocess.run(command,check=True)
    lib=ctypes.CDLL(str(library));fn=lib.b12x_export_bench;fn.argtypes=[ctypes.c_void_p]*5+[ctypes.c_int,ctypes.POINTER(ctypes.c_double)];fn.restype=ctypes.c_int
    n,k=17408,5120;packed,scales,decoded=fixture(n,k,17)
    storage=scales.view(torch.uint8).reshape(n//128,4,32,k//64,4).permute(0,3,2,1,4).contiguous()
    torch.backends.cuda.matmul.allow_tf32=False
    with (args.output/"results.jsonl").open("w") as log:
      for global_value in [1.,.137]:
        alpha=torch.tensor([global_value],device="cuda",dtype=torch.float32)
        for m in [1,5,16]:
          _,_,x=fixture(m,k,3);reference=(x.float()@decoded.float().T)*alpha;y=torch.empty((m,n),device="cuda",dtype=torch.bfloat16);torch.cuda.synchronize()
          times=(ctypes.c_double*6)();status=fn(x.data_ptr(),packed.data_ptr(),storage.data_ptr(),alpha.data_ptr(),y.data_ptr(),m,times)
          result=dict(m=m,n=n,k=k,weight_global=global_value,status=status,native_times_us=list(times),same_quantized_weights=metrics(y,reference),aot_export=True,split_k=4)
          line=json.dumps(result);print(line,flush=True);log.write(line+"\n");log.flush()
          if status or not result["same_quantized_weights"]["finite"] or result["same_quantized_weights"]["relative_l2"]>.005:raise RuntimeError("exported b12x correctness failed")
if __name__=="__main__":main()
