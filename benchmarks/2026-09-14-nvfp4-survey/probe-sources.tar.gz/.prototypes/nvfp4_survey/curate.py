"""Copy small raw evidence and source snapshots into the durable benchmark report."""
from pathlib import Path
import hashlib
import gzip
import json
import shutil
import tarfile

repo = Path(__file__).resolve().parents[2]
out = repo / 'benchmarks/2026-09-14-nvfp4-survey'
evidence = out / 'evidence'
evidence.mkdir(exist_ok=True)
manifest = []
keep = {'results.csv','results.jsonl','metadata.json','manifest.json','exit.json','gpu.csv',
        'memory.txt','command.json','build_command.json','b12x.json','moe.json','inventory.json',
        'checkpoints.json','environment.json','reference.json','qualification.json',
        'b12x_sweep.json','moe_routing_sweep.json','vllm_checkpoint.json','process.json',
        'export_inputs.json','compile_command.json','run_mode.json','real_moe.json',
        'source_tensors.json','job.json','pins.json','results.json','FINISHED.json',
        'image.json','checkpoint-config.json','vllm-worker.log'}
for run in sorted((repo / '.prototypes/out').glob('nvfp4-*')):
    for p in sorted(run.rglob('*')):
        if not p.is_file() or 'source' in p.relative_to(run).parts or 'cache' in p.relative_to(run).parts:
            continue
        if p.name not in keep:
            continue
        dest = evidence / p.relative_to(repo / '.prototypes/out')
        dest.parent.mkdir(exist_ok=True, parents=True)
        if p.stat().st_size > 400_000:
            if dest.exists(): dest.unlink()
            dest = dest.with_suffix(dest.suffix + '.gz')
            dest.write_bytes(gzip.compress(p.read_bytes(), mtime=0))
        else:
            shutil.copy2(p,dest)
        manifest.append(dict(path=str(dest.relative_to(out)),bytes=dest.stat().st_size,
                             sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
(out / 'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
notes = out / 'research-notes'
shutil.copytree(Path(__file__).parent/'notes', notes, dirs_exist_ok=True)
for p in notes.rglob('*.json'):
    if p.stat().st_size > 400_000:
        p.with_suffix(p.suffix + '.gz').write_bytes(gzip.compress(p.read_bytes(), mtime=0))
        p.unlink()
with tarfile.open(out/'probe-sources.tar.gz','w:gz') as archive:
    for p in sorted(Path(__file__).parent.rglob('*')):
        if p.is_file() and not any(x in p.parts for x in ('vendor','__pycache__')):
            archive.add(p,arcname=str(p.relative_to(repo)))
    archive.add(repo/'.prototypes/justfile',arcname='.prototypes/justfile')
print(f'{len(manifest)} evidence files, source archive and research notes in {out}')
