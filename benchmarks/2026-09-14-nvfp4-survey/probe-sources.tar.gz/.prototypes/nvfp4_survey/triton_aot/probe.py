"""Compile minimal NVFP4 paths offline; inspect PTX, do not run a GPU."""
import json
import os
from pathlib import Path

import triton
import triton.language as tl
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource


@triton.jit
def dot_kernel(A, B, AS, BS, C, M: tl.int32, N: tl.int32,
               K: tl.int32, BM: tl.constexpr, BN: tl.constexpr,
               BK: tl.constexpr, FP4_A: tl.constexpr, SPLIT_K: tl.constexpr):
    m = tl.program_id(0) * BM + tl.arange(0, BM)
    n = tl.program_id(1) * BN + tl.arange(0, BN)
    ka = tl.arange(0, BK // 2 if FP4_A else BK)
    kb = tl.arange(0, BK // 2)
    ks = tl.arange(0, BK // 16)
    acc = tl.zeros((BM, BN), tl.float32)
    for ki in range(tl.program_id(2) * (K // BK // SPLIT_K), (tl.program_id(2) + 1) * (K // BK // SPLIT_K)):
        b = tl.load(B + n[:, None] * (K // 2) + ki * (BK // 2) + kb[None, :], n[:, None] < N, 0)
        bs = tl.load(BS + n[:, None] * (K // 16) + ki * (BK // 16) + ks[None, :], n[:, None] < N, 0.0)
        if FP4_A:
            a = tl.load(A + m[:, None] * (K // 2) + ki * (BK // 2) + ka[None, :], m[:, None] < M, 0)
            a_s = tl.load(AS + m[:, None] * (K // 16) + ki * (BK // 16) + ks[None, :], m[:, None] < M, 0.0)
            acc = tl.dot_scaled(a, a_s, "e2m1", b.T, bs, "e2m1", acc)
        else:
            a = tl.load(A + m[:, None] * K + ki * BK + ka[None, :], m[:, None] < M, 0)
            acc = tl.dot_scaled(a, None, "bf16", b.T, bs, "e2m1", acc)
    tl.store(C + tl.program_id(2) * M * N + m[:, None] * N + n[None, :], acc, (m[:, None] < M) & (n[None, :] < N))


@triton.jit
def gemv_kernel(A, B, AS, BS, C, M: tl.int32, N: tl.int32,
                K: tl.int32, BM: tl.constexpr, BN: tl.constexpr,
                BK: tl.constexpr, FP4_A: tl.constexpr, SPLIT_K: tl.constexpr):
    # Same byte-pointer/dimension ABI as dot_kernel; no activation quantization.
    # Put output rows on grid.x: vocabulary projection N exceeds grid.y's
    # 65535-block limit, while grid.x supports the complete model vocabulary.
    m = tl.program_id(1) * BM + tl.arange(0, BM)
    n = tl.program_id(0)
    kp = tl.arange(0, BK // 2)
    ks = tl.arange(0, BK // 16)
    kk = tl.arange(0, BK)
    products = tl.full((BM, BK), 0, tl.float32)
    for chunk in range(tl.cdiv(K, BK)):
        packed = tl.load(B + n * (K // 2) + chunk * (BK // 2) + kp, chunk * (BK // 2) + kp < K // 2, 0)
        halves = tl.inline_asm_elementwise(
            "{ .reg .b8 x; .reg .f16x2 y; cvt.u8.u32 x, $1; cvt.rn.f16x2.e2m1x2 y, x; mov.b32 $0, y; }",
            constraints="=r,r", args=[packed], dtype=tl.uint32, is_pure=True, pack=1)
        lo = (halves & 65535).to(tl.uint16).to(tl.float16, bitcast=True)
        hi = (halves >> 16).to(tl.uint16).to(tl.float16, bitcast=True)
        weights = tl.interleave(lo, hi).to(tl.float32)
        scale = tl.load(BS + n * (K // 16) + chunk * (BK // 16) + ks, chunk * (BK // 16) + ks < K // 16, 0.0).to(tl.float32)
        weights = (weights.reshape(BK // 16, 16) * scale[:, None]).reshape(BK)
        activation = tl.load(A + m[:, None] * K + chunk * BK + kk[None, :], (m[:, None] < M) & (chunk * BK + kk[None, :] < K), 0.0).to(tl.float32)
        products += activation * weights[None, :]
    value = tl.sum(products, axis=1)
    tl.store(C + m * N + n, value, m < M)


def main():
    out = Path(os.environ.get("QS3_NVFP4_TRITON_OUTPUT", str(Path(__file__).parent / "out")))
    out.mkdir(exist_ok=True)
    records = []
    variants = []
    for fp4_a in (True, False):
        for bm, bn, bk, split in ((16, 32, 128, 1), (16, 64, 128, 1), (16, 64, 256, 1), (16, 32, 128, 4), (16, 64, 256, 4)):
            name = f'{"w4a4" if fp4_a else "w4a16"}_{bm}_{bn}_{bk}_s{split}'
            variants.append((name, dot_kernel, bm, bn, bk, split, fp4_a, 4, 2))
    for fp4_a, bn, bk in ((True, 32, 128), (True, 64, 256), (False, 64, 256)):
        variants.append((f'{"w4a4" if fp4_a else "w4a16"}_16_{bn}_{bk}_s1_aligned', dot_kernel, 16, bn, bk, 1, fp4_a, 4, 2))
    for bm, bk, warps in ((1, 512, 4), (1, 1024, 4), (4, 512, 4), (16, 512, 8)):
        variants.append((f"gemv_w4a16_m{bm}_k{bk}_w{warps}", gemv_kernel, bm, 1, bk, 1, False, warps, 1))
    for name, fn, bm, bn, bk, split, fp4_a, warps, stages in variants:
        signature = dict(A="*u8" if fp4_a else "*bf16", B="*u8", AS="*fp8e4nv", BS="*fp8e4nv", C="*fp32", M="i32", N="i32", K="i32")
        constants = dict(BM=bm, BN=bn, BK=bk, FP4_A=fp4_a, SPLIT_K=split)
        # All fixtures have cudaMalloc alignment and N/K divisible by 256.
        # Preserve the original dot kernels as controls; explicitly label hints.
        attrs = {}
        if name.endswith("aligned") or fn is gemv_kernel:
            for arg in ("A", "B", "AS", "BS", "C"):
                attrs[(fn.arg_names.index(arg),)] = [["tt.divisibility", 16]]
            for arg in ("N", "K"):
                attrs[(fn.arg_names.index(arg),)] = [["tt.divisibility", 256]]
        try:
            obj = triton.compile(ASTSource(fn, signature=signature, constexprs=constants, attrs=attrs),
                                 target=GPUTarget("cuda", 121, 32), options=dict(num_warps=warps, num_stages=stages))
            ptx = obj.asm["ptx"]
            (out / f"{name}.ptx").write_text(ptx)
            (out / f"{name}.cubin").write_bytes(obj.asm["cubin"])
            record = dict(name=name, success=True, shared=obj.metadata.shared,
                          instructions=sorted(set(line.strip() for line in ptx.splitlines() if "mma.sync" in line)),
                          metadata=obj.metadata._asdict(), constants=constants, signature=signature,
                          alignment_hints=bool(attrs))
        except Exception as error:
            record = dict(name=name, success=False, error=str(error))
        records.append(record)
        print(name, record.get("success"), record.get("shared", record.get("error")), flush=True)
    (out / "manifest.json").write_text(json.dumps(dict(triton=triton.__version__, kernels=records), indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
