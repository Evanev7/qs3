"""Offline Triton compilation + native CUDA-driver correctness/timing probe."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--compile-only", action="store_true")
    parser.add_argument("--lm-head", action="store_true", help="Append 27B LM-head M=1/5/16 with bounded timing iterations")
    parser.add_argument("--lm-head-only", action="store_true", help="Run only the optional large LM-head case")
    args = parser.parse_args()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    here = Path(__file__).resolve().parent
    repo = here.parents[2]
    env = dict(os.environ, TRITON_CACHE_DIR=str(args.output / "cache"), QS3_NVFP4_TRITON_OUTPUT=str(args.output))
    subprocess.run([sys.executable, str(here / "probe.py")], env=env, check=True)
    manifest = json.loads((args.output / "manifest.json").read_text())
    manifest["native_sources_sha256"] = {str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest() for path in (here / "bench.cu", repo / "qscb.cu", repo / "qscb.h")}
    manifest["qscb_workspace_bytes"] = 64 << 20
    manifest["baseline_outputs"] = {"qscb_bf16_out": "bf16", "qscb_f32_out": "fp32", "cublas_bf16": "fp32"}
    manifest["lm_head_mode"] = "only" if args.lm_head_only else "append" if args.lm_head else "disabled"
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    kernels = manifest["kernels"]
    assert all(k["success"] for k in kernels)
    lines = ["struct KernelSpec { const char* name; const char* symbol; int bm,bn,bk,shared,split,warps; bool fp4_a; };", "static KernelSpec kernels[]={"]
    for kernel in kernels:
        c = kernel["constants"]
        lines.append('{"%s","%s",%d,%d,%d,%d,%d,%d,%s},' % (kernel["name"], kernel["metadata"]["name"], c["BM"], c["BN"], c["BK"], kernel["shared"], c["SPLIT_K"], kernel["metadata"]["num_warps"], str(c["FP4_A"]).lower()))
    lines.append("};")
    (args.output / "kernels.h").write_text("\n".join(lines))
    nvcc = shutil.which("nvcc") or "/usr/local/cuda/bin/nvcc"
    command = [nvcc, "-O3", "-std=c++17", "-arch=sm_121a", "-I" + str(args.output), "-I" + str(repo), str(here / "bench.cu"), str(repo / "qscb.cu"), "-lcuda", "-lcublas", "-lcublasLt", "-o", str(args.output / "bench")]
    (args.output / "build_command.json").write_text(json.dumps(command, indent=2))
    subprocess.run(command, check=True)
    if not args.compile_only:
        bench_env = dict(os.environ)
        if args.lm_head or args.lm_head_only:
            bench_env["QS3_NVFP4_LM_HEAD"] = "only" if args.lm_head_only else "1"
        subprocess.run([str(args.output / "bench"), str(args.output)], env=bench_env, check=True)


if __name__ == "__main__":
    main()
