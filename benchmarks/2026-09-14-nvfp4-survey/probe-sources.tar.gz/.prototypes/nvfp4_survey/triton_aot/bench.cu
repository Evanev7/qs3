#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cublas_v2.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include "kernels.h"
#include "qscb.h"

#define CK(x) do { auto e=(x); if(e!=0) { fprintf(stderr,"%s: %d at %d\n",#x,(int)e,__LINE__); exit(1); } } while(0)
__host__ __device__ float fp4(unsigned n) {
  const float v[8]={0,.5f,1,1.5f,2,3,4,6}; return (n&8)?-v[n&7]:v[n&7];
}
// Exact E4M3 scale values in [0.5, 0.9375], varied over rows and K blocks.
__global__ void fill(unsigned char* packed,unsigned char* scales,__nv_bfloat16* dense,int rows,int k,int seed) {
  size_t pair=blockIdx.x*blockDim.x+threadIdx.x;
  if(pair>=size_t(rows)*k/2)return;
  size_t row=pair/(k/2), kp=pair%(k/2);
  unsigned h=unsigned(pair)^unsigned(seed*0x9e3779b9u); h^=h>>16; h*=0x7feb352du; h^=h>>15; h*=0x846ca68bu; h^=h>>16; unsigned a=h&15, b=(h>>8)&15;
  unsigned char s=0x30+((row*3+(kp/8)*5+seed)&7);
  float sf=.5f+(s-0x30)*.0625f;
  packed[pair]=a|(b<<4);
  if(kp%8==0)scales[row*(k/16)+kp/8]=s;
  dense[pair*2]=__float2bfloat16(fp4(a)*sf);
  dense[pair*2+1]=__float2bfloat16(fp4(b)*sf);
}

__global__ void reduce(float* dst,const float* src,int count,int splits) { int i=blockIdx.x*blockDim.x+threadIdx.x;if(i<count){float sum=0;for(int s=0;s<splits;s++)sum+=src[s*count+i];dst[i]=sum;}}

__global__ void evict_l2(unsigned* p,size_t count) { size_t i=size_t(blockIdx.x)*blockDim.x+threadIdx.x;if(i<count)p[i]+=1; }
static bool large_case=false;
template<class F> float time_us(F fn,void* eviction=nullptr,int iters=100) {
  if(large_case)iters=8;
  for(int i=0;i<(large_case?2:10);i++)fn();
  cudaEvent_t a,b; CK(cudaEventCreate(&a));CK(cudaEventCreate(&b));
  float ms=0;
  if(eviction){
    iters=large_case?5:30;
    for(int i=0;i<iters;i++){
      evict_l2<<<(128*1024*1024/sizeof(unsigned)+255)/256,256>>>((unsigned*)eviction,128*1024*1024/sizeof(unsigned));CK(cudaGetLastError());
      CK(cudaEventRecord(a));fn();CK(cudaEventRecord(b));CK(cudaEventSynchronize(b));
      float sample;CK(cudaEventElapsedTime(&sample,a,b));ms+=sample;
    }
  }else{CK(cudaEventRecord(a));for(int i=0;i<iters;i++)fn();CK(cudaEventRecord(b));CK(cudaEventSynchronize(b));CK(cudaEventElapsedTime(&ms,a,b));}
  CK(cudaEventDestroy(a));CK(cudaEventDestroy(b));return ms*1000/iters;
}
struct Buffer { void* p; Buffer(size_t n){CK(cudaMalloc(&p,n));}~Buffer(){cudaFree(p);} };
static qsfi_tensor2 tensor(void* ptr,qsfi_dtype dtype,int rows,int cols){return {ptr,dtype,{rows,cols},{cols,1}};}
int main(int argc,char** argv) {
  if(argc!=2){fprintf(stderr,"usage: bench OUTDIR\n");return 1;}
  std::string out=argv[1]; CK(cudaSetDevice(0)); CK(cudaFree(nullptr));
  cudaDeviceProp prop;CK(cudaGetDeviceProperties(&prop,0));
  fprintf(stderr,"device=%s sm=%d%d\n",prop.name,prop.major,prop.minor);
  cublasHandle_t blas;CK(cublasCreate(&blas));CK(cublasSetMathMode(blas,CUBLAS_DEFAULT_MATH));
  qscb_context* qscb=nullptr;qscb_context_desc context_desc{0,nullptr};CK(qscb_context_create(&context_desc,&qscb));
  Buffer qscb_workspace(64*1024*1024);
  Buffer eviction(128*1024*1024);CK(cudaMemset(eviction.p,0,128*1024*1024));
  std::vector<CUmodule> modules;std::vector<CUfunction> funcs;
  for(auto& spec:kernels){CUmodule mod;CUfunction fn;CK(cuModuleLoad(&mod,(out+"/"+spec.name+".cubin").c_str()));CK(cuModuleGetFunction(&fn,mod,spec.symbol));modules.push_back(mod);funcs.push_back(fn);}
  std::ofstream csv(out+"/results.csv");csv<<"m,n,k,kernel,cache,trial,us,max_abs_error,relative_l2_error,weight_gbps\n";
  std::vector<std::pair<int,int>> shapes={{17408,5120},{5120,17408},{10240,5120},{1024,2048}};
  const char* lm_head=std::getenv("QS3_NVFP4_LM_HEAD");
  if(lm_head){if(std::string(lm_head)=="only")shapes.clear();shapes.push_back({248320,5120});}
  for(auto& shape:shapes){int n=shape.first,k=shape.second;large_case=n==248320;
    Buffer wq(size_t(n)*k/2),ws(size_t(n)*k/16),wd(size_t(n)*k*2);
    fill<<<(size_t(n)*k/2+255)/256,256>>>((unsigned char*)wq.p,(unsigned char*)ws.p,(__nv_bfloat16*)wd.p,n,k,17);CK(cudaGetLastError());
    const std::vector<int> rows=large_case?std::vector<int>{1,5,16}:std::vector<int>{1,2,4,5,16};
    for(int m:rows){
      Buffer aq(size_t(m)*k/2),as(size_t(m)*k/16),ad(size_t(m)*k*2),y(size_t(m)*n*4),ref(size_t(m)*n*4),partial(size_t(m)*n*4*4);
      fill<<<(size_t(m)*k/2+255)/256,256>>>((unsigned char*)aq.p,(unsigned char*)as.p,(__nv_bfloat16*)ad.p,m,k,3);CK(cudaGetLastError());
      float alpha=1,beta=0;
      auto bf16=[&](){CK(cublasGemmEx(blas,CUBLAS_OP_T,CUBLAS_OP_N,n,m,k,&alpha,wd.p,CUDA_R_16BF,k,ad.p,CUDA_R_16BF,k,&beta,ref.p,CUDA_R_32F,n,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));};
      bf16();
      std::vector<float> reference(size_t(m)*n),actual(size_t(m)*n);CK(cudaMemcpy(reference.data(),ref.p,reference.size()*4,cudaMemcpyDeviceToHost));
      for(bool cold:{false,true})for(int trial=0;trial<3;trial++){
        float baseline=time_us(bf16,cold?eviction.p:nullptr);
        csv<<m<<','<<n<<','<<k<<",cublas_bf16,"<<(cold?"evicted128MiB":"warm")<<','<<trial<<','<<baseline<<",0,0,"<<(size_t(n)*k*2/baseline/1000)<<'\n';csv.flush();
      }
      for(qsfi_dtype dtype:{QSFI_DTYPE_BF16,QSFI_DTYPE_F32}){
        const char* name=dtype==QSFI_DTYPE_BF16?"qscb_bf16_out":"qscb_f32_out";
        qscb_linear_desc desc{};desc.x=tensor(ad.p,QSFI_DTYPE_BF16,m,k);desc.weight=tensor(wd.p,QSFI_DTYPE_BF16,n,k);desc.out=tensor(y.p,dtype,m,n);
        desc.rows=m;desc.in_features=k;desc.out_features=n;desc.alpha=1;desc.workspace=qscb_workspace.p;desc.workspace_bytes=64*1024*1024;
        qscb_linear_plan* plan=nullptr;CK(qscb_linear_plan_create(qscb,&desc,&plan));
        auto run_qscb=[&](){CK(qscb_linear_execute(qscb,plan,&desc));};run_qscb();
        if(dtype==QSFI_DTYPE_F32){CK(cudaMemcpy(actual.data(),y.p,actual.size()*4,cudaMemcpyDeviceToHost));}
        else{std::vector<__nv_bfloat16> bf(actual.size());CK(cudaMemcpy(bf.data(),y.p,bf.size()*2,cudaMemcpyDeviceToHost));for(size_t i=0;i<bf.size();i++)actual[i]=__bfloat162float(bf[i]);}
        double e2=0,r2=0;float maxerr=0;
        for(size_t i=0;i<actual.size();i++){float expected=dtype==QSFI_DTYPE_BF16?__bfloat162float(__float2bfloat16(reference[i])):reference[i];double d=double(actual[i])-expected;e2+=d*d;r2+=double(expected)*expected;maxerr=std::max(maxerr,float(std::abs(d)));}
        double rel=std::sqrt(e2/std::max(r2,1e-30));if(!std::isfinite(rel)||rel>1e-4){fprintf(stderr,"qscb mismatch %s M%d N%d K%d err=%g rel=%g\n",name,m,n,k,maxerr,rel);return 3;}
        for(bool cold:{false,true})for(int trial=0;trial<3;trial++){
          float us=time_us(run_qscb,cold?eviction.p:nullptr);
          csv<<m<<','<<n<<','<<k<<','<<name<<','<<(cold?"evicted128MiB":"warm")<<','<<trial<<','<<us<<','<<maxerr<<','<<rel<<','<<(size_t(n)*k*2/us/1000)<<'\n';csv.flush();
        }
        qscb_linear_plan_destroy(plan);
      }
      for(size_t si=0;si<funcs.size();si++){
        auto spec=kernels[si];void* a=spec.fp4_a?aq.p:ad.p;void* b=wq.p;void* sa=as.p;void* sb=ws.p;void* c=spec.split==1?y.p:partial.p;void* scratch=nullptr;
        void* args[]={&a,&b,&sa,&sb,&c,&m,&n,&k,&scratch,&scratch};
        bool gemv=std::string(spec.symbol)=="gemv_kernel";
        unsigned grid_x=gemv?n:(m+spec.bm-1)/spec.bm;
        unsigned grid_y=gemv?(m+spec.bm-1)/spec.bm:(n+spec.bn-1)/spec.bn;
        auto launch=[&](){CK(cuLaunchKernel(funcs[si],grid_x,grid_y,spec.split,32*spec.warps,1,1,spec.shared,nullptr,args,nullptr));if(spec.split>1){reduce<<<(m*n+255)/256,256>>>((float*)y.p,(float*)partial.p,m*n,spec.split);CK(cudaGetLastError());}};
        launch();CK(cudaMemcpy(actual.data(),y.p,actual.size()*4,cudaMemcpyDeviceToHost));
        double err2=0,ref2=0;float maxerr=0;
        for(size_t i=0;i<actual.size();i++){double d=double(actual[i])-reference[i];if(!std::isfinite(actual[i])){fprintf(stderr,"nonfinite %s\n",spec.name);return 2;}err2+=d*d;ref2+=double(reference[i])*reference[i];maxerr=std::max(maxerr,float(std::abs(d)));}
        double rel=std::sqrt(err2/std::max(ref2,1e-30));if(rel>1e-4){fprintf(stderr,"mismatch %s %d,%d,%d max=%g rel=%g\n",spec.name,m,n,k,maxerr,rel);return 2;}
        for(bool cold:{false,true})for(int trial=0;trial<3;trial++){
          float us=time_us(launch,cold?eviction.p:nullptr);
          csv<<m<<','<<n<<','<<k<<','<<spec.name<<','<<(cold?"evicted128MiB":"warm")<<','<<trial<<','<<us<<','<<maxerr<<','<<rel<<','<<(size_t(n)*k*.5625/us/1000)<<'\n';csv.flush();
        }
      }
      fprintf(stderr,"validated and timed M%d N%d K%d\n",m,n,k);
    }
  }
  for(auto mod:modules)CK(cuModuleUnload(mod));qscb_context_destroy(qscb);CK(cublasDestroy(blas));
}
