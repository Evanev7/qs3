"""Bounded offline/eager smoke test of a pinned NVIDIA NVFP4 checkpoint.

Run through host.py vllm_checkpoint_probe. A child process group has a 300s
wall deadline, including imports/loading, and records every completed stage.
No checkpoint rewriting, graph capture, speculation, or tokenizer/network IO.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

PINS = {item["name"]: item for item in json.loads(
    Path(__file__).with_name("download-pins.json").read_text())}


def write(path, value):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, default=str) + "\n")
    tmp.replace(path)


def model_backends(model):
    counts, examples = Counter(), []
    for name, module in model.named_modules():
        method = getattr(module, "quant_method", None)
        if method is None:
            continue
        entry = dict(name=name, method=type(method).__name__)
        for key in ("backend", "nvfp4_backend", "use_a16", "kernel", "experts_cls"):
            value = getattr(method, key, None)
            if value is not None:
                entry[key] = str(value) if key in ("backend", "nvfp4_backend", "use_a16") else str(type(value) if not isinstance(value, type) else value)
        counts[json.dumps({k: v for k, v in entry.items() if k != "name"}, sort_keys=True)] += 1
        if len(examples) < 35:
            examples.append(entry)
    return dict(model_class=type(model).__name__, quantized_method_counts=dict(counts), examples=examples)


def worker(args):
    started = time.monotonic()
    pin = PINS[args.model]
    snapshot = Path("/hf") / ("models--" + pin["repo"].replace("/", "--")) / "snapshots" / pin["rev"]
    report = dict(status="starting", model_name=args.model, model_repo=pin["repo"],
                  snapshot=str(snapshot), revision=pin["rev"],
                  prompt_ids=[1, 2, 3, 4], max_new_tokens=4, graphs=False,
                  precision="checkpoint-declared linear precision; explicit BF16 KV cache",
                  model_runner="v1", versions={})
    target = args.output / "vllm_checkpoint.json"
    def save(stage):
        report.update(stage=stage, elapsed_seconds=time.monotonic()-started)
        write(target, report)
        print(json.dumps(dict(stage=stage, status=report["status"], elapsed_seconds=report["elapsed_seconds"])), flush=True)
    try:
        raw = (snapshot / "config.json").read_bytes()
        assert hashlib.sha256(raw).hexdigest() == pin["config_sha256"], "checkpoint config does not match pinned metadata"
        config = json.loads(raw)
        (args.output / "checkpoint-config.json").write_bytes(raw)
        quant = config["quantization_config"]
        required = Counter(v["quant_algo"] for v in quant["quantized_layers"].values())
        report.update(config_sha256=hashlib.sha256(raw).hexdigest(), required_layer_algorithms=dict(required))
        for package in ("vllm", "torch", "transformers", "flashinfer-python", "nvidia-cutlass-dsl"):
            try:
                report["versions"][package] = importlib.metadata.version(package)
            except importlib.metadata.PackageNotFoundError:
                report["versions"][package] = None
        save("checkpoint-read")
        import torch
        import vllm
        from vllm import LLM, SamplingParams
        from vllm import envs as vllm_envs
        from vllm.engine.arg_utils import EngineArgs
        from vllm.model_executor.layers.quantization import modelopt
        from vllm.model_executor.layers.linear import LinearBase
        from vllm.config import set_current_vllm_config
        assert vllm_envs.VLLM_USE_V2_MODEL_RUNNER is False
        cls = modelopt.ModelOptMixedPrecisionConfig
        source = inspect.getsource(cls)
        (args.output / "installed-modelopt-mixed.py").write_text(source)
        report["installed_vllm"] = dict(path=vllm.__file__, modelopt_path=modelopt.__file__,
                                         quant_algorithms=getattr(modelopt, "QUANT_ALGOS", None),
                                         mixed_class_sha256=hashlib.sha256(source.encode()).hexdigest())
        parsed = cls.from_config(quant)
        report["parsed_quant_config"] = dict(type=type(parsed).__name__, name=parsed.get_name())
        options = dict(model=str(snapshot), dtype="bfloat16", quantization=None,
                       skip_tokenizer_init=True, tensor_parallel_size=1, max_num_seqs=1,
                       max_model_len=256, max_num_batched_tokens=256,
                       enable_prefix_caching=False, enable_chunked_prefill=False,
                       enforce_eager=True, gpu_memory_utilization=.5,
                       kv_cache_memory_bytes=256 << 20, kv_cache_dtype="bfloat16",
                       mamba_cache_dtype="auto", mamba_ssm_cache_dtype="float32",
                       limit_mm_per_prompt={"image": 0, "video": 0},
                       moe_backend="marlin", seed=0)
        report["options"] = options
        engine_args = EngineArgs(**options)
        preflight_config = engine_args.create_engine_config()
        report["engine_arguments_accepted"] = str(engine_args.moe_backend)
        report["preflight_kv_cache_dtype"] = preflight_config.cache_config.cache_dtype
        # Kernel selection reads get_current_vllm_config in 0.29. Use the real
        # parsed engine configuration, before creating any checkpoint weights.
        # Minimal layers exercise actual isinstance/algorithm/constructor paths.
        expected = {"FP8": "ModelOptFp8LinearMethod",
                    "NVFP4": "ModelOptNvFp4LinearMethod",
                    "W4A16_NVFP4": "ModelOptNvFp4W4A16LinearMethod"}
        dispatch = []
        with set_current_vllm_config(preflight_config):
            for algorithm in sorted(required):
                prefix = next(k for k, v in quant["quantized_layers"].items()
                              if v["quant_algo"] == algorithm and not k.endswith("experts"))
                layer = object.__new__(LinearBase)
                torch.nn.Module.__init__(layer)
                method = parsed.get_quant_method(layer, prefix)
                entry = dict(prefix=prefix, algorithm=algorithm,
                             method=type(method).__name__,
                             kernel=type(getattr(method, "kernel", None)).__name__)
                dispatch.append(entry)
                report["preflight_dispatch"] = dispatch
                assert type(method).__name__ == expected[algorithm], (
                    f"incorrect checkpoint precision dispatch: {entry}")
        save("quantization-dispatch-checked")
        if args.preflight_only:
            report["status"] = "preflight_ok"
            save("stopped-before-model-allocation")
            return
        report["gpu"] = dict(name=torch.cuda.get_device_name(), capability=torch.cuda.get_device_capability())
        save("starting-model-load")
        load_started = time.monotonic()
        llm = LLM(**options)
        report["load_seconds"] = time.monotonic()-load_started
        resolved = llm.llm_engine.vllm_config
        report["resolved_config"] = str(resolved)
        report["resolved_quantization"] = str(resolved.model_config.quantization)
        report["resolved_kernel_config"] = str(resolved.kernel_config)
        report["resolved_compilation_config"] = str(resolved.compilation_config)
        report["resolved_kv_cache_dtype"] = resolved.cache_config.cache_dtype
        assert resolved.model_config.enforce_eager
        assert resolved.cache_config.cache_dtype == "bfloat16"
        report["model_backends"] = llm.apply_model(model_backends)
        save("model-loaded")
        params = SamplingParams(temperature=0, max_tokens=4, ignore_eos=True,
                                detokenize=False, logprobs=5)
        generation_started = time.monotonic()
        outputs = llm.generate([{"prompt_token_ids": [1, 2, 3, 4]}], params, use_tqdm=False)
        report["generation_seconds"] = time.monotonic()-generation_started
        result = outputs[0].outputs[0]
        report["generated_ids"] = list(result.token_ids)
        report["finish_reason"] = result.finish_reason
        report["logprobs"] = [
            {str(token): dict(logprob=value.logprob, rank=value.rank) for token, value in step.items()}
            for step in (result.logprobs or [])]
        assert len(report["generated_ids"]) == 4
        report["status"] = "ok"
        save("generation-complete")
    except Exception as error:
        report.update(status="error", error=repr(error), traceback=traceback.format_exc())
        save("failed")
        traceback.print_exc()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=300)
    parser.add_argument("--model", choices=list(PINS), default="qwen3.6-35b-a3b-nvfp4")
    parser.add_argument("--preflight-only", action="store_true")
    parser.add_argument("--worker", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for key, value in {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
                       "VLLM_NO_USAGE_STATS": "1", "PYTHONUNBUFFERED": "1",
                       "VLLM_USE_V2_MODEL_RUNNER": "0",
                       "VLLM_ENABLE_V1_MULTIPROCESSING": "0"}.items():
        os.environ[key] = value
    if args.worker:
        worker(args)
        return
    command = [sys.executable, str(Path(__file__).resolve()), "--output", str(args.output),
               "--model", args.model, "--worker"]
    if args.preflight_only:
        command.append("--preflight-only")
    metadata = dict(command=command, timeout_seconds=args.timeout, network="offline; host container network=none")
    with (args.output / "vllm-worker.log").open("w") as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            metadata["returncode"] = process.wait(timeout=args.timeout)
            metadata["timed_out"] = False
        except subprocess.TimeoutExpired:
            metadata["timed_out"] = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            metadata["returncode"] = process.returncode
    write(args.output / "process.json", metadata)
    print(json.dumps(metadata), flush=True)
    print((args.output / "vllm-worker.log").read_text()[-16000:], flush=True)


if __name__ == "__main__":
    main()
