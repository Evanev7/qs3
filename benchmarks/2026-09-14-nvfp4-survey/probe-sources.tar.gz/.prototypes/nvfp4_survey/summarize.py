from pathlib import Path
import csv,collections,statistics,json
base=Path(__file__).resolve().parents[1]/'out';out=Path(__file__).resolve().parents[2]/'benchmarks/2026-09-14-nvfp4-survey'
tr=collections.defaultdict(list)
for r in csv.DictReader((base/'nvfp4-triton-20260914T191423Z-lp19lw3a/results.csv').open()):
 if r['cache']=='evicted128MiB':tr[(int(r['m']),int(r['n']),int(r['k']),r['kernel'])].append(float(r['us']))
tr={k:statistics.median(v) for k,v in tr.items()}
fi=collections.defaultdict(list)
for r in csv.DictReader((base/'nvfp4-native_flashinfer-20260914T185943Z-yq70tlg_/results.csv').open()):fi[(int(r['m']),int(r['n']),int(r['k']),r['kernel'])].append(float(r['evicted_us']))
fi={k:statistics.median(v) for k,v in fi.items()}
ma=collections.defaultdict(list)
for line in (base/'nvfp4-native_marlin-20260914T191921Z-o8ndstb3/results.jsonl').read_text().splitlines():
 r=json.loads(line)
 if 'm' in r:ma[(r['m'],r['n'],r['k'])].append(statistics.median(r['native_times_us'][1::2]))
rows=[]
for n,k in [(17408,5120),(5120,17408),(10240,5120),(1024,2048)]:
 for m in [1,5,16]:
  fival=min(v for key,v in fi.items() if key[:3]==(m,n,k) and 'quant_plus' in key[3])
  t4=min(v for key,v in tr.items() if key[:3]==(m,n,k) and 'w4a4' in key[3]);t16=min(v for key,v in tr.items() if key[:3]==(m,n,k) and 'w4a16' in key[3])
  rows.append([m,n,k,tr[(m,n,k,'qscb_bf16_out')],fival,t4,t16,min(ma[(m,n,k)])])
with (out/'dense-summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['m','n','k','qscb_bf16_us','fi_w4a4_pipeline_us','triton_w4a4_us','triton_w4a16_us','marlin_w4a16_us']);w.writerows(rows)
with (out/'dense-table.md').open('w') as f:
 f.write('| N × K | M | qs3 cuBLASLt BF16 | FI W4A4 incl. quant | Triton W4A4* | Triton W4A16 | Marlin W4A16 |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: |\n')
 for m,n,k,*times in rows:f.write(f'| {n} × {k} | {m} | '+' | '.join(f'{t:.1f}' for t in times)+' |\n')
 f.write('\n*The Triton W4A4 column excludes activation quantization. Each column uses its best measured native tactic; no dynamic runtime tuning is proposed. CSV: [dense-summary.csv](dense-summary.csv).\n')
