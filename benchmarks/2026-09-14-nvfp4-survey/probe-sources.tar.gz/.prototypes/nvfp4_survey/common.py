"""Shared graph-free event timing for exploratory Python provider calls."""
import statistics
import torch


def measure(fn, flush_bytes=64 << 20, repeats=30):
    for _ in range(5):
        fn()
    torch.cuda.synchronize()
    flush = torch.zeros(flush_bytes // 4, dtype=torch.int32, device="cuda") if flush_bytes else None
    result = {}
    for mode in ("warm", "evicted") if flush is not None else ("warm",):
        pairs = [(torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True))
                 for _ in range(repeats)]
        for start, end in pairs:
            if mode == "evicted":
                flush.add_(1)
            start.record()
            fn()
            end.record()
        torch.cuda.synchronize()
        samples = [start.elapsed_time(end) * 1000 for start, end in pairs]
        result[mode] = dict(median_us=statistics.median(samples), min_us=min(samples), samples_us=samples)
    return result


def metrics(actual, expected):
    a, e = actual.float().flatten(), expected.float().flatten()
    delta = a - e
    return dict(relative_l2=float(delta.norm() / e.norm().clamp_min(1e-30)),
                cosine=float(torch.nn.functional.cosine_similarity(a, e, dim=0)),
                max_abs=float(delta.abs().max()), finite=bool(torch.isfinite(a).all()))
