"""Install only the CuTe build toolchain into an isolated experiment directory."""
import argparse
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument("--output", type=Path, required=True)
a = p.parse_args()
packages = ["nvidia-cutlass-dsl==4.6.2", "nvidia-cutlass-dsl-libs-base==4.6.2",
            "nvidia-cutlass-dsl-libs-core==4.6.2", "nvidia-cutlass-dsl-libs-cu13==4.6.2"]
command = [sys.executable, "-m", "pip", "install", "--target", "/toolchain", "--upgrade", "--no-deps", *packages]
(a.output / "install.json").write_text(json.dumps(command, indent=2) + "\n")
subprocess.run(command, check=True)
subprocess.run([sys.executable, "-c", "import cutlass, torch; print('cutlass', cutlass.__version__, cutlass.__file__, 'torch', torch.__version__)"], check=True)
