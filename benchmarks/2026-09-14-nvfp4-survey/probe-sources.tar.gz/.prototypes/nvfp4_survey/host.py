"""Run isolated NVFP4 experiments in the existing GPU container."""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import tarfile

IMAGE = os.environ.get("QS3_NVFP4_IMAGE", "vllm-node@sha256:d966c1831d5da55c0cc52c6bd40f7d02cfc3d83404c3bd599139b055232d3970")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase")
    parser.add_argument("--native", action="store_true")
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    prototypes = Path(__file__).resolve().parents[1]
    repo = prototypes.parent
    archive = Path(__file__).parent / "vendor/b12x-source.tar.gz"
    if archive.is_file():
        vendor = archive.parent / "b12x"
        vendor.mkdir(exist_ok=True)
        with tarfile.open(archive) as source:
            source.extractall(vendor, filter="data")
    (prototypes / "out").mkdir(exist_ok=True)
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output = Path(tempfile.mkdtemp(prefix=f"nvfp4-{args.phase}-{stamp}-", dir=prototypes / "out"))
    shutil.copytree(Path(__file__).parent, output / "source", ignore=shutil.ignore_patterns("__pycache__", "vendor"))
    for filename, command in (
        ("gpu.csv", ["nvidia-smi", "--query-gpu=name,driver_version,memory.total,memory.used,utilization.gpu,temperature.gpu", "--format=csv"]),
        ("image.json", ["docker", "image", "inspect", IMAGE]),
        ("memory.txt", ["free", "-h"]),
    ):
        with (output / filename).open("w") as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
    cache = Path.home() / "qs3-vllm-cache"
    cache.mkdir(exist_ok=True)
    toolchain = Path.home() / "qs3-nvfp4-toolchain"
    toolchain.mkdir(exist_ok=True)
    container_output = Path("/repo") / output.relative_to(repo)
    command = ["docker", "run", "--rm", "--gpus", "all", "--ipc=host",
               "--network=bridge" if args.phase == "toolchain" else "--network=none",
               "-e", "HF_HUB_OFFLINE=1", "-e", "TRANSFORMERS_OFFLINE=1",
               "-e", "VLLM_NO_USAGE_STATS=1", "-e", "PYTHONUNBUFFERED=1",
               "-e", "PYTHONPATH=" if args.phase == "vllm_checkpoint_probe" else "PYTHONPATH=/toolchain/nvidia_cutlass_dsl/dsl_packages:/toolchain",
               "-v", f"{repo}:/repo", "-v", f"{Path.home() / '.cache/huggingface/hub'}:/hf:ro",
               "-v", f"{toolchain}:/toolchain",
               "-v", f"{cache}:/root/.cache", "--entrypoint", "python3", IMAGE,
               f"/repo/.prototypes/nvfp4_survey/{args.phase}.py", "--output", str(container_output),
               *[arg.replace("{output}", str(container_output)) for arg in args.arguments]]
    if args.native:
        command = ["python3", str(Path(__file__).parent / f"{args.phase}.py"),
                   "--output", str(output),
                   *[arg.replace("{output}", str(output)) for arg in args.arguments]]
    (output / "command.json").write_text(json.dumps(command, indent=2) + "\n")
    print(f"NVFP4 {args.phase}: {output}", flush=True)
    with (output / "run.log").open("w") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    print((output / "run.log").read_text()[-12000:], flush=True)
    (output / "exit.json").write_text(json.dumps({"returncode": result.returncode}) + "\n")
    print(f"Artifacts: {output}", flush=True)
    # Return artifacts even when an experimental provider fails.


if __name__ == "__main__":
    main()
