"""Read-only payload accounting and global-scale audit of cached ModelOpt weights."""
import argparse
import collections
import json
import math
from pathlib import Path
from real_weights import Snapshot

p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
s=Snapshot(Path('/hf/models--nvidia--Qwen3.6-35B-A3B-NVFP4/snapshots/6c7f09d4036e97393f82e9f9ecd1a5c35ca5ee92'))
counts=collections.Counter();sizes=collections.Counter();scalar_groups=collections.defaultdict(list);bad=[]
for name,info in s.headers.items():
    counts[info['dtype']]+=1;sizes[info['dtype']]+=info['data_offsets'][1]-info['data_offsets'][0]
    if info['dtype']=='F32' and math.prod(info['shape'])==1 and 'scale' in name:
        value=s.scalar(name);scalar_groups[name.rsplit('.',1)[-1]].append(value)
        if not math.isfinite(value) or value<=0:bad.append({'name':name,'value':value})
config=json.loads((s.path/'config.json').read_text())
report={'snapshot':str(s.path),'tensor_counts':dict(counts),'payload_bytes':dict(sizes),
        'global_scales':{k:{'count':len(v),'min':min(v),'max':max(v)} for k,v in scalar_groups.items()},
        'invalid_global_scales':bad,'total_payload_bytes':sum(sizes.values()),
        'quantization_config':config.get('quantization_config')}
a.output.mkdir(parents=True,exist_ok=True);(a.output/'metadata.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='quantization_config'}),flush=True)
