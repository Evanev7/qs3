#!/usr/bin/env python3
"""Standalone synthetic W4A16/W4A4 b12x probe. No checkpoint or graphs.

PYTHONPATH=3pty/b12x python .prototypes/nvfp4_survey/b12x_probe.py \
    --n 17408 --k 5120 --rows 1 2 4 5 16 --output /tmp/b12x-up

Timings include activation quantization for W4A4, split-K reduction for A16,
and Python enqueue gaps. Setup/reference/compilation/eviction are excluded.
Use results as a kernel feasibility probe, not native-runtime launch timings.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import importlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import traceback

_prototype = Path(__file__).resolve().parent
_b12x_source = _prototype / "vendor" / "b12x"
if not (_b12x_source / "b12x" / "__init__.py").exists():
    _b12x_source = _prototype.parents[1] / "3pty" / "b12x"
sys.path.insert(0, str(_b12x_source))

import torch
import b12x
import cutlass

from b12x.gemm import blockscaled
from b12x.gemm.blockscaled import _a16
from b12x._lib.intrinsics import swizzle_block_scale


def unpack(packed):
    lut = torch.tensor([0, .5, 1, 1.5, 2, 3, 4, 6,
                        0, -.5, -1, -1.5, -2, -3, -4, -6], device=packed.device)
    codes = torch.stack((packed & 15, packed >> 4), dim=-1).flatten(-2)
    return lut[codes.long()]


def make_case(n, k, m, config=(128, 64, 4), weight_global=.137,
              activation_global=117.0, scale_mode="arbitrary"):
    """Return callables, outputs, matched references and owned storage."""
    torch.manual_seed(1701)
    device = "cuda"
    packed = torch.randint(0, 256, (n, k // 2), device=device, dtype=torch.uint8)
    if scale_mode == "powers-of-two":
        scales = torch.exp2(torch.randint(-3, 2, (n, k // 16), device=device).float())
    else:
        scales = torch.rand(n, k // 16, device=device) * 2 + .0625
    scales = scales.to(torch.float8_e4m3fn)
    storage = swizzle_block_scale(scales)
    wg = torch.tensor([weight_global], device=device)
    ag = torch.tensor([activation_global], device=device)  # quantizer multiplier
    weight = blockscaled.pack_weight(packed, storage, recipe="nvfp4", global_scale=wg)
    x = torch.randn(m, k, device=device, dtype=torch.bfloat16)
    decoded = (unpack(packed) * scales.float().repeat_interleave(16, 1)).bfloat16()
    reference_a16 = (x.float() @ decoded.float().T) * wg
    scratch_size = max(blockscaled.workspace_size(weight, m, _config=config),
                       _a16._layout(m, n, k, True)[-1])
    scratch = {mode: torch.empty(scratch_size, device=device, dtype=torch.uint8)
               for mode in ("a16", "quantized")}
    outputs = {mode: torch.empty(m, n, device=device, dtype=torch.bfloat16)
               for mode in scratch}
    calls = {
        mode: (lambda mode=mode: blockscaled.mm(
            x, weight, mode=mode, out=outputs[mode], workspace=scratch[mode],
            activation_global_scale=ag if mode == "quantized" else None,
            expected_m=m, _config=config if mode == "a16" else None))
        for mode in scratch
    }

    def reference_a4():
        # Decode actual quantizer output: isolates GEMM correctness from quant error.
        sf_start, _, _, _ = _a16._layout(m, n, k, True)
        q = scratch["quantized"][:m * k // 2].view(m, k // 2)
        rows = torch.arange(m, device=device)[:, None]
        groups = torch.arange(k // 16, device=device)[None, :]
        offset = ((rows // 128 * ((k // 16 + 3) // 4) + groups // 4) * 512
                  + rows % 32 * 16 + rows // 32 % 4 * 4 + groups % 4)
        sf = scratch["quantized"][sf_start + offset].view(torch.float8_e4m3fn).float()
        qx = unpack(q) * sf.repeat_interleave(16, 1) / ag
        return (qx @ decoded.float().T) * wg

    return calls, outputs, reference_a16, reference_a4


def quality(actual, expected):
    a, e = actual.float(), expected.float()
    relative = float(torch.linalg.vector_norm(a - e) / torch.linalg.vector_norm(e))
    cosine = float(torch.nn.functional.cosine_similarity(a.flatten(), e.flatten(), dim=0))
    result = dict(relative_l2=relative, cosine=cosine,
                  max_abs=float((a - e).abs().max()), finite=bool(torch.isfinite(a).all()))
    if not result["finite"] or relative > .008:
        raise RuntimeError(f"correctness failure: {result}")
    return result


def timings(call, warmup, iterations, flush=None):
    for _ in range(warmup):
        call()
    torch.cuda.synchronize()
    pairs = [(torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True))
             for _ in range(iterations)]
    for start, end in pairs:
        if flush is not None:
            flush.add_(1)
        start.record()
        call()
        end.record()
    torch.cuda.synchronize()
    values = [a.elapsed_time(b) * 1000 for a, b in pairs]
    return dict(median_us=statistics.median(values), min_us=min(values), samples_us=values)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n", type=int, default=17408)
    parser.add_argument("--k", type=int, default=5120)
    parser.add_argument("--rows", type=int, nargs="+", default=[1, 2, 4, 5, 16])
    parser.add_argument("--config", type=int, nargs=3, default=[128, 64, 4])
    parser.add_argument("--weight-global", type=float, default=.137)
    parser.add_argument("--activation-global", type=float, default=117.0)
    parser.add_argument("--scale-mode", choices=["arbitrary", "powers-of-two"],
                        default="arbitrary")
    parser.add_argument("--warmup", type=int, default=5)
    parser.add_argument("--iterations", type=int, default=30)
    parser.add_argument("--flush-mib", type=int, default=128)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--export-dir", type=Path,
                        help="Export actual CuTe compute/reduce .h/.o after compilation")
    args = parser.parse_args()
    torch.backends.cuda.matmul.allow_tf32 = False
    versions = {}
    for name in ("torch", "triton", "nvidia-cutlass-dsl", "apache-tvm-ffi"):
        try:
            versions[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            versions[name] = None
    b12x_path = Path(b12x.__file__).resolve()
    try:
        b12x_revision = subprocess.check_output(
            ["git", "-C", str(b12x_path.parent), "rev-parse", "HEAD"], text=True,
            stderr=subprocess.DEVNULL).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        b12x_revision = None
    report = dict(n=args.n, k=args.k, config=args.config, versions=versions,
                  weight_global=args.weight_global, activation_global=args.activation_global,
                  scale_mode=args.scale_mode,
                  gpu=torch.cuda.get_device_name(), capability=torch.cuda.get_device_capability(),
                  source=str(b12x_path), source_git_revision=b12x_revision,
                  imported_cutlass=dict(path=cutlass.__file__, version=getattr(cutlass, "__version__", None)),
                  cases=[], graph_replay=False)
    if args.export_dir:
        # Cached ExternalBinaryModule wrappers need not expose export_to_c.
        os.environ["B12X_COMPILE_DISK_CACHE"] = "0"
        args.export_dir.mkdir(parents=True, exist_ok=True)
        dense = importlib.import_module("b12x._lib.dense_gemm")
        original_compile = dense.b12x_compile
        exported = report["exports"] = []

        def compile_and_export(func, *compile_args, **compile_kwargs):
            compiled = original_compile(func, *compile_args, **compile_kwargs)
            name = f"qs3_b12x_{type(func).__name__.strip('_').lower()}_{len(exported)}"
            signature = [dict(type=type(value).__name__, representation=str(value))
                         for value in compile_args]
            try:
                compiled.export_to_c(file_path=str(args.export_dir), file_name=name,
                                     function_prefix=name)
                exported.append(dict(name=name, target=type(func).__name__, success=True,
                                     compile_argument_signature=signature))
            except Exception as exc:
                exported.append(dict(name=name, target=type(func).__name__,
                                     success=False, error=repr(exc),
                                     compile_argument_signature=signature))
            return compiled

        dense.b12x_compile = compile_and_export
    args.output.mkdir(parents=True, exist_ok=True)
    output_path = args.output / "b12x.json"
    def save():
        output_path.write_text(json.dumps(report, indent=2) + "\n")
    save()
    for m in args.rows:
        case = dict(m=m, arms={})
        report["cases"].append(case)
        try:
            calls, outputs, ref16, make_ref4 = make_case(
                args.n, args.k, m, tuple(args.config), args.weight_global,
                args.activation_global, args.scale_mode)
            flush = torch.empty(args.flush_mib * 1024**2 // 4, device="cuda", dtype=torch.int32)
            flush.zero_()
            for mode, call in calls.items():
                try:
                    start = time.monotonic()
                    call()
                    torch.cuda.synchronize()
                    compile_seconds = time.monotonic() - start
                    reference = ref16 if mode == "a16" else make_ref4()
                    checked = quality(outputs[mode], reference)
                    arm = dict(status="ok", quality=checked, first_call_seconds=compile_seconds,
                               warm=timings(call, args.warmup, args.iterations),
                               evicted=timings(call, args.warmup, args.iterations, flush))
                    outputs[mode].fill_(float("nan"))
                    call()
                    arm["post_timing_quality"] = quality(outputs[mode], reference)
                except Exception as exc:
                    arm = dict(status="error", error=repr(exc), traceback=traceback.format_exc())
                case["arms"][mode] = arm
                print(json.dumps(dict(m=m, mode=mode, **arm)), flush=True)
                save()
            del calls, outputs, ref16, make_ref4, flush
        except Exception as exc:
            case["error"] = repr(exc)
            case["traceback"] = traceback.format_exc()
            save()
    save()


if __name__ == "__main__":
    main()
