#!/usr/bin/env python3
"""vLLM NVFP4 Marlin W4A16 comparison, using original BF16 activations."""
import argparse
import json
from pathlib import Path

import torch
import flashinfer as fi

from common import measure, metrics
from flashinfer_probe import SHAPES, dequant


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--shapes", default="27b_gate,27b_down,27b_q,35b_gate_up,35b_down")
    ap.add_argument("--rows", default="1,2,4,5,16")
    ap.add_argument("--repeats", type=int, default=30)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "results.jsonl").open("w") as log:
        def emit(record):
            line = json.dumps(record)
            print(line, flush=True)
            log.write(line + "\n")
            log.flush()
        try:
            from vllm.model_executor.layers.quantization.utils.marlin_utils_fp4 import (
                prepare_fp4_layer_for_marlin, apply_fp4_marlin_linear,
            )
        except Exception as exc:
            emit(dict(status="import_error", error=str(exc)))
            return
        torch.manual_seed(42)
        torch.backends.cuda.matmul.allow_tf32 = False
        for name in args.shapes.split(","):
            n, k = SHAPES[name]
            try:
                w = torch.randn((n, k), dtype=torch.bfloat16, device="cuda")
                wg = (2688 / w.float().abs().max()).reshape(1)
                packed, swizzled = fi.nvfp4_quantize(w, wg, sfLayout=fi.SfLayout.layout_128x4)
                wd = dequant(packed, swizzled, wg)
                rp, kp = (n + 127) // 128 * 128, (k // 16 + 3) // 4 * 4
                scales = swizzled.contiguous().view(torch.float8_e4m3fn).reshape(
                    rp // 128, kp // 4, 32, 4, 4
                ).permute(0, 3, 2, 1, 4).reshape(rp, kp)[:n, :k // 16].contiguous()
                layer = torch.nn.Module()
                layer.output_size_per_partition, layer.input_size_per_partition = n, k
                layer.params_dtype = torch.bfloat16
                layer.weight = torch.nn.Parameter(packed, requires_grad=False)
                layer.weight_scale = torch.nn.Parameter(scales, requires_grad=False)
                layer.weight_global_scale = torch.nn.Parameter(1 / wg, requires_grad=False)
                prepare_fp4_layer_for_marlin(layer)
                for m in map(int, args.rows.split(",")):
                    x = torch.randn((m, k), dtype=torch.bfloat16, device="cuda")
                    def fn():
                        return apply_fp4_marlin_linear(
                            input=x, weight=layer.weight, weight_scale=layer.weight_scale,
                            weight_global_scale=layer.weight_global_scale,
                            workspace=layer.workspace, size_n=n, size_k=k,
                        )
                    y = fn()
                    emit(dict(status="ok", backend="vllm_marlin_w4a16", shape=name, m=m, n=n, k=k,
                              same_quantized_weights=metrics(y, x.float() @ wd.T),
                              original_bf16_operands=metrics(y, x.float() @ w.float().T),
                              gemm=measure(fn, repeats=args.repeats),
                              bf16=measure(lambda: x @ w.T, repeats=args.repeats)))
            except Exception as exc:
                emit(dict(status="error", shape=name, error_type=type(exc).__name__, error=str(exc)))


if __name__ == "__main__":
    main()
