"""Start a detached, pinned snapshot-download queue in the normal HF cache."""
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

IMAGE='vllm-node@sha256:d966c1831d5da55c0cc52c6bd40f7d02cfc3d83404c3bd599139b055232d3970'
here=Path(__file__).resolve().parent
pins=json.loads((here/'download-pins.json').read_text())
root=here.parent
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=Path(tempfile.mkdtemp(prefix=f'nvfp4-downloads-{stamp}-',dir=root/'out'))
hub=Path.home()/'.cache/huggingface/hub';hub.mkdir(parents=True,exist_ok=True)
shutil.copy2(here/'download-pins.json',out/'pins.json')
worker='''import json, traceback, datetime, hashlib\nfrom pathlib import Path\nfrom huggingface_hub import snapshot_download\nroot=Path('/job'); pins=json.loads((root/'pins.json').read_text()); results=[]\nfor item in pins:\n    record=dict(item,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())\n    try:\n        print('Downloading',item['repo'],item['rev'],flush=True)\n        path=snapshot_download(repo_id=item['repo'],revision=item['rev'],cache_dir='/hf',max_workers=4)\n        snapshot=Path(path); index=json.loads((snapshot/'model.safetensors.index.json').read_text())\n        shards=sorted(set(index['weight_map'].values()))\n        assert all((snapshot/name).is_file() for name in shards)\n        assert len(shards)==item['shard_count']\n        assert sum((snapshot/name).stat().st_size for name in shards)==item['expected_shard_bytes']\n        for filename,key in [('config.json','config_sha256'),('hf_quant_config.json','hf_quant_config_sha256'),('model.safetensors.index.json','index_sha256')]:\n            assert hashlib.sha256((snapshot/filename).read_bytes()).hexdigest()==item[key], filename\n        record.update(status='complete',snapshot=path,shards=len(shards),payload_bytes=sum((snapshot/name).stat().st_size for name in shards))\n    except Exception as error:\n        record.update(status='error',error=repr(error),traceback=traceback.format_exc())\n    record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();results.append(record)\n    (root/'results.json').write_text(json.dumps(results,indent=2)+'\\n');print(json.dumps(record),flush=True)\n(root/'FINISHED.json').write_text(json.dumps({'success':all(x['status']=='complete' for x in results),'models':len(results)})+'\\n')\n'''
(out/'worker.py').write_text(worker)
name=f'qs3-nvfp4-downloads-{stamp.lower()}'
command=['docker','run','--detach','--name',name,'--network=bridge','--user',f'{os.getuid()}:{os.getgid()}',
         '-e','HF_HUB_CACHE=/hf','-e','HF_HOME=/tmp/hf-home','-e','PYTHONUNBUFFERED=1',
         '-v',f'{hub}:/hf','-v',f'{out}:/job','--entrypoint','python3',IMAGE,'/job/worker.py']
(out/'command.json').write_text(json.dumps(command,indent=2)+'\n')
container=subprocess.check_output(command,text=True).strip()
record={'container':container,'name':name,'output':str(out),'cache':str(hub),'pins':pins}
(out/'job.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
