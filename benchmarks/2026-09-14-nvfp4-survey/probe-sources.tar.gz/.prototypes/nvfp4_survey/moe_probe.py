#!/usr/bin/env python3
"""Full routed b12x MoE probe at Qwen35B geometry, graph-free.

The parent isolates precision modes in sequential subprocesses so a failed
CUDA kernel in one precision does not poison the other. Timing includes GPU
dispatch/routing, gate+up, SiLU multiplication, down and weighted reduction.
Caller top-k ids/weights, host plan/bind, allocation and compilation are setup.
No router-logit projection, softmax/top-k selection or shared expert is timed.
Requires the vendored b12x API at75ffee6 and its CUTLASS4.6.2 toolchain.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback

REPO = Path(__file__).resolve().parents[2]
_b12x_source = Path(__file__).resolve().parent / "vendor" / "b12x"
if not (_b12x_source / "b12x" / "__init__.py").exists():
    _b12x_source = REPO / "3pty" / "b12x"
sys.path.insert(0, str(_b12x_source))


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rows", type=int, nargs="+", default=[1, 2, 4, 5, 16])
    parser.add_argument("--experts", type=int, default=256)
    parser.add_argument("--hidden", type=int, default=2048)
    parser.add_argument("--intermediate", type=int, default=512)
    parser.add_argument("--top-k", type=int, default=8)
    parser.add_argument("--modes", nargs="+", choices=["a16", "a4"], default=["a16", "a4"])
    parser.add_argument("--routing", choices=["diverse", "shared"], default="diverse")
    parser.add_argument("--a16-route-mode", choices=["auto", "packed", "chunked-direct"], default="auto")
    parser.add_argument("--iterations", type=int, default=30)
    parser.add_argument("--flush-mib", type=int, default=128)
    parser.add_argument("--worker-mode", choices=["a16", "a4"])
    return parser.parse_args()


def save(path, report):
    path.write_text(json.dumps(report, indent=2) + "\n")


def parent(args):
    result = dict(graphs=False, source="synthetic native NVFP4", modes={})
    for mode in args.modes:
        child = args.output / mode
        child.mkdir(exist_ok=True)
        command = [sys.executable, str(Path(__file__).resolve()), "--output", str(child),
                   "--worker-mode", mode, "--experts", str(args.experts),
                   "--hidden", str(args.hidden), "--intermediate", str(args.intermediate),
                   "--top-k", str(args.top_k), "--routing", args.routing,
                   "--a16-route-mode", args.a16_route_mode,
                   "--iterations", str(args.iterations), "--flush-mib", str(args.flush_mib),
                   "--rows", *map(str, args.rows)]
        with (child / "run.log").open("w") as log:
            completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        item = dict(returncode=completed.returncode, command=command)
        if (child / "moe.json").exists():
            item["report"] = json.loads((child / "moe.json").read_text())
        result["modes"][mode] = item
        save(args.output / "moe.json", result)
        print((child / "run.log").read_text()[-10000:], flush=True)


def worker(args):
    import torch
    import b12x
    from b12x._lib.intrinsics import swizzle_block_scale
    from b12x.moe import fused_moe
    from b12x.moe._shared.kernels.reference import moe_reference_nvfp4
    from tests._reference.w4a16_reference import moe_reference_w4a16
    from b12x.policy import MOE_DECODE, get_auto_policy
    from common import measure, metrics

    torch.backends.cuda.matmul.allow_tf32 = False
    torch.manual_seed(6327)
    device = torch.device("cuda", 0)
    torch.cuda.set_device(device)
    e, h, i, topk = args.experts, args.hidden, args.intermediate, args.top_k
    if h % 128 or i % 128 or e < topk or min(args.rows) < 1:
        raise ValueError("positive rows, E>=topk and H/I divisible by128 required")
    report = dict(mode=args.worker_mode, geometry=dict(experts=e, hidden=h, intermediate=i, topk=topk),
                  routing=args.routing, source=str(Path(b12x.__file__).resolve()),
                  a16_route_mode=args.a16_route_mode,
                  gpu=torch.cuda.get_device_name(), capability=torch.cuda.get_device_capability(),
                  seed=6327, cases=[], graph_replay=False,
                  timing_scope="internal route dispatch + both projections + SiLU + weighted reduction; supplied topk ids/weights",
                  scale_contract="native packed E2M1, swizzled E4M3 K/16, weight-global multipliers, activation quantizer multipliers",
                  w13_order="up, gate")
    report["versions"] = {}
    import cutlass
    report["imported_cutlass"] = dict(path=cutlass.__file__, version=getattr(cutlass, "__version__", None))
    for name in ("torch", "triton", "nvidia-cutlass-dsl", "apache-tvm-ffi"):
        try:
            report["versions"][name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            report["versions"][name] = None
    path = args.output / "moe.json"
    save(path, report)

    def scales(shape):
        # Kept deliberately modest to avoid synthetic overflow through SiLU.
        return swizzle_block_scale((torch.rand(shape, device=device) * .1 + .03).to(torch.float8_e4m3fn))

    started = time.monotonic()
    weights = fused_moe.PackedWeights(
        w13=torch.randint(0, 256, (e, 2*i, h//2), device=device, dtype=torch.uint8),
        w2=torch.randint(0, 256, (e, h, i//2), device=device, dtype=torch.uint8),
        w13_block_scales=scales((e, 2*i, h//16)),
        w2_block_scales=scales((e, h, i//16)),
        w13_global_scales=torch.rand(e, device=device) * .1 + .1,
        w2_global_scales=torch.rand(e, device=device) * .1 + .1,
        input_scale=torch.full((e,), 117.0, device=device),
        intermediate_scale=torch.full((e,), 509.0, device=device),
    )
    weight_plan = fused_moe.plan_weights(
        source=fused_moe.PackedSource(format="modelopt_nvfp4", w13_layout="w13"),
        geometry=fused_moe.MoEGeometry(num_experts=e, hidden_size=h, intermediate_size=i),
        activation=fused_moe.ActivationSpec(mode=fused_moe.ActivationMode.AUTO,
                                            nonlinearity="silu", io_dtype=torch.bfloat16),
        constraints=fused_moe.WeightPlanConstraints(required_packing=fused_moe.WeightPacking.SOURCE_NATIVE),
    )
    experts = fused_moe.prepare_weights(plan=weight_plan, weights=weights)
    native = experts._impl.representation_for("w4a16")
    for original, prepared in ((weights.w13, native.w13), (weights.w2, native.w2),
                               (weights.w13_block_scales, native.w13_scale),
                               (weights.w2_block_scales, native.w2_scale)):
        assert original.data_ptr() == prepared.data_ptr(), "unexpected native-weight copy"
    torch.cuda.synchronize()
    report["weight_setup_seconds"] = time.monotonic() - started
    report["weight_storage_bytes"] = sum(t.numel()*t.element_size() for t in vars(weights).values()
                                         if isinstance(t, torch.Tensor))
    report["native_payload_shared"] = True
    save(path, report)
    plans = {}
    for m in args.rows:
        case = dict(m=m)
        report["cases"].append(case)
        save(path, report)
        try:
            small = m <= 8
            chunk_size = m
            if args.worker_mode == "a16":
                route_mode = "direct" if small else "packed"
                if args.a16_route_mode == "packed":
                    route_mode = "packed"
                elif args.a16_route_mode == "chunked-direct":
                    route_mode = "direct"
                    chunk_size = 8
                config = fused_moe.MoeDecodeConfig(
                    backend="w4a16", route_planner="internal", max_active_clusters=None,
                    w4a16_route_mode=route_mode)
            elif small:
                config = fused_moe.MoeDecodeConfig(
                    backend="micro", route_planner="internal", max_active_clusters=None)
            else:
                config = fused_moe.MoeDecodeConfig(
                    backend="dynamic", route_planner="internal", max_active_clusters=None,
                    dynamic_tile_m=16, dynamic_route_mode="grouped")
            group_rows = tuple(row for row in args.rows if (row <= 8) == small)
            if args.worker_mode == "a16" and args.a16_route_mode == "packed":
                group_rows = tuple(args.rows)
            elif args.worker_mode == "a16" and args.a16_route_mode == "chunked-direct":
                group_rows = tuple(sorted({min(row, 8) for row in args.rows}
                                         | {row % 8 for row in args.rows if row % 8}))
            key = max(group_rows)
            if key not in plans:
                started = time.monotonic()
                plan = fused_moe.plan_execution(
                    experts=experts,
                    capacity=fused_moe.ExecutionCapacity(max_tokens=key, top_k=topk,
                                                         warmup_token_counts=group_rows),
                    policy=get_auto_policy(device).with_override(MOE_DECODE, config))
                fused_moe.prewarm(plan)
                spec, = plan.scratch_specs()
                scratch = torch.empty(spec.shape, dtype=spec.dtype, device=device)
                torch.cuda.synchronize()
                plans[key] = (plan, scratch)
                case["plan_compile_seconds"] = time.monotonic() - started
            plan, scratch = plans[key]
            torch.manual_seed(9900 + m)
            x = (torch.randn(m, h, device=device)*.25).to(torch.bfloat16)
            # Both duplicate-prefix and independent-expert routing can be probed.
            base = torch.arange(topk, device=device, dtype=torch.int32)[None, :] * 29
            token = torch.arange(m, device=device, dtype=torch.int32)[:, None]
            ids = ((base + token * (11 if args.routing == "diverse" else 0)) % e).contiguous()
            ids = ids.expand(m, topk).contiguous()
            if any(len(set(row)) != topk for row in ids.cpu().tolist()):
                raise ValueError("synthetic id pattern repeats experts within a row")
            routes = torch.softmax(torch.randn(m, topk, device=device), dim=-1)
            output = torch.full_like(x, float("nan"))
            bindings = [fused_moe.bind(plan, scratch=scratch, a=x[start:start+chunk_size], experts=experts,
                                      topk_ids=ids[start:start+chunk_size], topk_weights=routes[start:start+chunk_size],
                                      output=output[start:start+chunk_size], input_scales_static=True)
                        for start in range(0, m, chunk_size)]
            def run():
                for binding in bindings:
                    fused_moe.run(binding=binding)
            started = time.monotonic()
            if args.worker_mode == "a16":
                expected = moe_reference_w4a16(
                    x, weights.w13, weights.w13_block_scales, weights.w13_global_scales,
                    weights.w2, weights.w2_block_scales, weights.w2_global_scales,
                    ids, routes, e, h, i)
                case["oracle"] = "b12x tests/_reference/w4a16_reference.py:moe_reference_w4a16"
            else:
                expected = moe_reference_nvfp4(
                    x, weights.w13, weights.w13_block_scales, experts._impl.w1_alphas,
                    weights.w2, weights.w2_block_scales, experts._impl.w2_alphas,
                    weights.input_scale, weights.intermediate_scale,
                    ids, routes, e, h, i,
                    quant_scale_math="reciprocal_multiply" if small else "direct_division")
                case["oracle"] = "b12x moe/_shared/kernels/reference.py:moe_reference_nvfp4"
            torch.cuda.synchronize()
            case["oracle_seconds"] = time.monotonic() - started
            run()
            torch.cuda.synchronize()
            checked = metrics(output, expected)
            checked["nonzero"] = bool(output.count_nonzero())
            checked["reference_finite"] = bool(torch.isfinite(expected).all())
            checked["reference_nonzero"] = bool(expected.count_nonzero())
            case["quality"] = checked
            case["config"] = vars(config)
            case["moe_calls_per_iteration"] = len(bindings)
            case["chunk_size"] = chunk_size
            case["unique_experts"] = int(ids.unique().numel())
            case["routed_rows"] = m * topk
            case["scratch_bytes"] = scratch.numel() * scratch.element_size()
            # A16 upstream tolerance is cosine>=.9975; A4 is>=.9999. Keep an
            # additional scale-sensitive relative-L2 gate to reject wrong globals.
            cosine_min = .9975 if args.worker_mode == "a16" else .9999
            relative_max = .08 if args.worker_mode == "a16" else .025
            case["thresholds"] = dict(cosine_min=cosine_min, relative_l2_max=relative_max)
            if (not all(checked[key] for key in ("finite", "nonzero", "reference_finite", "reference_nonzero"))
                    or checked["cosine"] < cosine_min or checked["relative_l2"] > relative_max):
                raise AssertionError(f"MoE correctness gate failed: {checked}")
            case["correctness_passed"] = True
            case["timing"] = measure(run, flush_bytes=args.flush_mib*1024**2,
                                      repeats=args.iterations)
            output.fill_(float("nan"))
            run()
            torch.cuda.synchronize()
            case["post_timing_quality"] = metrics(output, expected)
            post = case["post_timing_quality"]
            case["post_timing_passed"] = bool(post["finite"] and post["cosine"] >= cosine_min
                                               and post["relative_l2"] <= relative_max)
            if not case["post_timing_passed"]:
                raise AssertionError(f"post-timing poison replay failed: {post}")
            print(json.dumps(case), flush=True)
        except Exception as exc:
            case["error"] = repr(exc)
            case.setdefault("correctness_passed", False)
            case["traceback"] = traceback.format_exc()
            print(case["traceback"], flush=True)
        save(path, report)


def main():
    args = arguments()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.worker_mode:
        worker(args)
    else:
        parent(args)


if __name__ == "__main__":
    main()
