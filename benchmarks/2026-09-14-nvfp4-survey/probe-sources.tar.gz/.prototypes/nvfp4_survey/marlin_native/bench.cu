#include "kernel.h"
#include "marlin_template.h"
#include <algorithm>
#include <cstdio>
#include <vector>
#define CK(x) do { auto status=(x);if(status!=cudaSuccess){fprintf(stderr,"%s: %s\n",#x,cudaGetErrorString(status));return int(status);} } while(0)
using Fn=void(*)(MARLIN_KERNEL_PARAMS);
template<int TN,int TK,int TH,bool M8> Fn kernel(){return marlin::Marlin<vllm::kBFloat16.id(),vllm::kFE2M1f.id(),vllm::kBFloat16.id(),vllm::kFE4M3fn.id(),TH,1,TN/16,TK/16,M8,4,1,false>;}
__global__ void evict(unsigned* p,size_t n){size_t i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)p[i]++;}
extern "C" int marlin_bench(const void* a,const void* b,void* c,const void* scales,const void* global,int m,int n,int k,int tactic,double* times){
 int device=0;CK(cudaGetDevice(&device));cudaDeviceProp prop;CK(cudaGetDeviceProperties(&prop,device));int smem=0;CK(cudaDeviceGetAttribute(&smem,cudaDevAttrMaxSharedMemoryPerBlockOptin,device));
 Fn fn;int threads;
 if(tactic==0){fn=m<=8?kernel<128,128,256,true>():kernel<128,128,256,false>();threads=256;}
 else{fn=m<=8?kernel<64,128,128,true>():kernel<64,128,128,false>();threads=128;}
 CK(cudaFuncSetAttribute(fn,cudaFuncAttributeMaxDynamicSharedMemorySize,smem));
 void *tmp,*locks,*cache;CK(cudaMalloc(&tmp,size_t(prop.multiProcessorCount)*16*256*4));CK(cudaMalloc(&locks,prop.multiProcessorCount*4));CK(cudaMemset(locks,0,prop.multiProcessorCount*4));CK(cudaMalloc(&cache,128<<20));CK(cudaMemset(cache,0,128<<20));
 auto launch=[&](){fn<<<prop.multiProcessorCount,threads,smem>>>((const int4*)a,(const int4*)b,(int4*)c,(int4*)tmp,nullptr,nullptr,(const int4*)scales,(const float*)global,nullptr,nullptr,k/16,m,n,k,k,(int*)locks,false,false,true,smem);};
 for(int i=0;i<10;i++)launch();CK(cudaDeviceSynchronize());
 cudaEvent_t start,end;CK(cudaEventCreate(&start));CK(cudaEventCreate(&end));
 for(int trial=0;trial<3;trial++)for(int cold=0;cold<2;cold++){
  std::vector<float> samples;for(int rep=0;rep<50;rep++){
   if(cold)evict<<<((128<<20)/4+255)/256,256>>>((unsigned*)cache,(128<<20)/4);
   CK(cudaEventRecord(start));launch();CK(cudaEventRecord(end));CK(cudaEventSynchronize(end));float ms;CK(cudaEventElapsedTime(&ms,start,end));samples.push_back(ms*1000);
  }std::sort(samples.begin(),samples.end());times[trial*2+cold]=samples[samples.size()/2];
 }
 CK(cudaEventDestroy(start));CK(cudaEventDestroy(end));CK(cudaFree(cache));CK(cudaFree(locks));CK(cudaFree(tmp));return 0;
}
