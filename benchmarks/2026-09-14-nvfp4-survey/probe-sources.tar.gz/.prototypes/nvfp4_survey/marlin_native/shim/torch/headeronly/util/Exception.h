// Prototype-only removal of the scalar metadata header's Torch dependency.
#pragma once
#include <stdexcept>
#define STD_TORCH_CHECK(condition, ...) do { if (!(condition)) throw std::runtime_error("scalar metadata check failed: " #condition); } while (0)
