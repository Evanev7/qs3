// Bounded tensor-scaled W8A8 probe; fixed caller-owned device scales, no graphs.
#include <cuda_runtime.h>
#include <cuda_bf16.h>
#include <cuda_fp8.h>
#include <cublasLt.h>
#include <cublas_v2.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#define CK(x) do{auto e=(x);if(e!=0){fprintf(stderr,"%s: %d line%d\n",#x,(int)e,__LINE__);exit(1);}}while(0)
struct Buffer{void* p;size_t n;Buffer(size_t n_):n(n_){CK(cudaMalloc(&p,n));CK(cudaMemset(p,0,n));}~Buffer(){cudaFree(p);}};
__global__ void fill(__nv_bfloat16* p,size_t n,int seed){size_t i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n){unsigned h=unsigned(i)^unsigned(seed*0x9e3779b9u);h^=h>>16;h*=0x7feb352du;h^=h>>15;p[i]=__float2bfloat16((int(h%2049)-1024)/1024.f);}}
__global__ void quant(const __nv_bfloat16* x,__nv_fp8_e4m3* q,const float* scale,size_t n){size_t i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)q[i]=__nv_fp8_e4m3(__bfloat162float(x[i])/(*scale));}
__global__ void dequant(const __nv_fp8_e4m3* q,__nv_bfloat16* x,const float* scale,size_t n){size_t i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)x[i]=__float2bfloat16(float(q[i])*(*scale));}
__global__ void evict(unsigned* p,size_t n){size_t i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)p[i]++;}
template<class F> float measure(F fn,Buffer* cache=nullptr){for(int i=0;i<10;i++)fn();CK(cudaDeviceSynchronize());cudaEvent_t a,b;CK(cudaEventCreate(&a));CK(cudaEventCreate(&b));std::vector<float> v;for(int i=0;i<40;i++){if(cache)evict<<<(cache->n/4+255)/256,256>>>((unsigned*)cache->p,cache->n/4);CK(cudaEventRecord(a));fn();CK(cudaEventRecord(b));CK(cudaEventSynchronize(b));float ms;CK(cudaEventElapsedTime(&ms,a,b));v.push_back(ms*1000);}CK(cudaEventDestroy(a));CK(cudaEventDestroy(b));std::sort(v.begin(),v.end());return v[v.size()/2];}
int main(int argc,char** argv){
 if(argc!=2)return 1;CK(cudaSetDevice(0));cublasLtHandle_t lt;CK(cublasLtCreate(&lt));cublasHandle_t blas;CK(cublasCreate(&blas));
 std::ofstream out(std::string(argv[1])+"/results.csv");out<<"m,n,k,operation,trial,warm_us,evicted_us,relative_l2_error,max_abs_error\n";
 Buffer cache(128<<20),workspace(32<<20),ag(4),wg(4);float as=1.f/128,ws=1.f/256,alpha=1,beta=0;CK(cudaMemcpy(ag.p,&as,4,cudaMemcpyHostToDevice));CK(cudaMemcpy(wg.p,&ws,4,cudaMemcpyHostToDevice));
 const int shapes[][2]={{10240,5120},{5120,6144}};
 for(auto& s:shapes){int n=s[0],k=s[1];Buffer w(size_t(n)*k*2),wq(size_t(n)*k),wd(size_t(n)*k*2);fill<<<(size_t(n)*k+255)/256,256>>>((__nv_bfloat16*)w.p,size_t(n)*k,17);quant<<<(size_t(n)*k+255)/256,256>>>((__nv_bfloat16*)w.p,(__nv_fp8_e4m3*)wq.p,(float*)wg.p,size_t(n)*k);dequant<<<(size_t(n)*k+255)/256,256>>>((__nv_fp8_e4m3*)wq.p,(__nv_bfloat16*)wd.p,(float*)wg.p,size_t(n)*k);
  for(int m:{1,4,16}){Buffer x(size_t(m)*k*2),xq(size_t(m)*k),xd(size_t(m)*k*2),y(size_t(m)*n*2),ref(size_t(m)*n*4);fill<<<(size_t(m)*k+255)/256,256>>>((__nv_bfloat16*)x.p,size_t(m)*k,3);
   auto q=[&](){quant<<<(size_t(m)*k+255)/256,256>>>((__nv_bfloat16*)x.p,(__nv_fp8_e4m3*)xq.p,(float*)ag.p,size_t(m)*k);};q();dequant<<<(size_t(m)*k+255)/256,256>>>((__nv_fp8_e4m3*)xq.p,(__nv_bfloat16*)xd.p,(float*)ag.p,size_t(m)*k);
   auto baseline=[&](){CK(cublasGemmEx(blas,CUBLAS_OP_T,CUBLAS_OP_N,n,m,k,&alpha,wd.p,CUDA_R_16BF,k,xd.p,CUDA_R_16BF,k,&beta,ref.p,CUDA_R_32F,n,CUBLAS_COMPUTE_32F,CUBLAS_GEMM_DEFAULT_TENSOR_OP));};baseline();std::vector<float> r(size_t(m)*n);CK(cudaMemcpy(r.data(),ref.p,r.size()*4,cudaMemcpyDeviceToHost));
   cublasLtMatmulDesc_t d;CK(cublasLtMatmulDescCreate(&d,CUBLAS_COMPUTE_32F,CUDA_R_32F));cublasOperation_t trans=CUBLAS_OP_T;CK(cublasLtMatmulDescSetAttribute(d,CUBLASLT_MATMUL_DESC_TRANSA,&trans,sizeof(trans)));
   CK(cublasLtMatmulDescSetAttribute(d,CUBLASLT_MATMUL_DESC_A_SCALE_POINTER,&wg.p,sizeof(wg.p)));CK(cublasLtMatmulDescSetAttribute(d,CUBLASLT_MATMUL_DESC_B_SCALE_POINTER,&ag.p,sizeof(ag.p)));
   cublasLtMatrixLayout_t a,b,c;CK(cublasLtMatrixLayoutCreate(&a,CUDA_R_8F_E4M3,k,n,k));CK(cublasLtMatrixLayoutCreate(&b,CUDA_R_8F_E4M3,k,m,k));CK(cublasLtMatrixLayoutCreate(&c,CUDA_R_16BF,n,m,n));
   cublasLtMatmulPreference_t pref;CK(cublasLtMatmulPreferenceCreate(&pref));CK(cublasLtMatmulPreferenceSetAttribute(pref,CUBLASLT_MATMUL_PREF_MAX_WORKSPACE_BYTES,&workspace.n,sizeof(workspace.n)));
   cublasLtMatmulHeuristicResult_t hr[8];int count=0;CK(cublasLtMatmulAlgoGetHeuristic(lt,d,a,b,c,c,pref,8,hr,&count));int chosen=-1;
   for(int i=0;i<count;i++)if(hr[i].state==CUBLAS_STATUS_SUCCESS){auto st=cublasLtMatmul(lt,d,&alpha,wq.p,a,xq.p,b,&beta,y.p,c,y.p,c,&hr[i].algo,workspace.p,workspace.n,nullptr);if(st==CUBLAS_STATUS_SUCCESS){chosen=i;break;}}
   if(chosen<0){fprintf(stderr,"noFP8heuristic M%d N%d K%d count%d\n",m,n,k,count);out<<m<<','<<n<<','<<k<<",unsupported,0,0,0,0,0\n";continue;}
   auto gemm=[&](){CK(cublasLtMatmul(lt,d,&alpha,wq.p,a,xq.p,b,&beta,y.p,c,y.p,c,&hr[chosen].algo,workspace.p,workspace.n,nullptr));};gemm();std::vector<__nv_bfloat16> yhost(size_t(m)*n);CK(cudaMemcpy(yhost.data(),y.p,yhost.size()*2,cudaMemcpyDeviceToHost));double e2=0,r2=0;float maxe=0;for(size_t i=0;i<r.size();i++){double diff=double(__bfloat162float(yhost[i]))-r[i];e2+=diff*diff;r2+=double(r[i])*r[i];maxe=std::max(maxe,float(std::abs(diff)));}double rel=std::sqrt(e2/std::max(r2,1e-30));if(!std::isfinite(rel)||rel>.005){fprintf(stderr,"FP8mismatch rel=%g\n",rel);return 2;}
   auto pipeline=[&](){q();gemm();};for(int trial=0;trial<3;trial++){for(int op=0;op<4;op++){float warm,cold;const char* name;if(op==0){name="cublas_bf16_fp32out";warm=measure(baseline);cold=measure(baseline,&cache);}else if(op==1){name="fp8_quant";warm=measure(q);cold=measure(q,&cache);}else if(op==2){name="fp8_cublaslt";warm=measure(gemm);cold=measure(gemm,&cache);}else{name="fp8_quant_cublaslt";warm=measure(pipeline);cold=measure(pipeline,&cache);}out<<m<<','<<n<<','<<k<<','<<name<<','<<trial<<','<<warm<<','<<cold<<','<<rel<<','<<maxe<<'\n';out.flush();}}
   cublasLtMatmulPreferenceDestroy(pref);cublasLtMatrixLayoutDestroy(a);cublasLtMatrixLayoutDestroy(b);cublasLtMatrixLayoutDestroy(c);cublasLtMatmulDescDestroy(d);fprintf(stderr,"FP8validated M%d N%d K%d\n",m,n,k);
  }
 }cublasDestroy(blas);cublasLtDestroy(lt);
}
