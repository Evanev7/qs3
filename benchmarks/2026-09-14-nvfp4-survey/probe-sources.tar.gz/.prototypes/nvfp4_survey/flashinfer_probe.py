#!/usr/bin/env python3
"""Synthetic SM121 NVFP4 survey. Explicit providers, no CUDA graphs.

Timings use warmed operands and include Python launch gaps; report GEMM-only,
activation-quantization-only, and quantization+GEMM separately. Global activation
scale is precomputed (checkpoint-like); weight preparation is outside timings.
Correctness compares to FP32 GEMM of the SAME quantized operands and additionally
reports distortion against original BF16 operands. No model-quality claim.
"""
import argparse
import gc
import json
import time
from pathlib import Path

import torch
import flashinfer as fi
from common import measure


SHAPES = {
    "27b_gate": (17408, 5120),
    "27b_gate_up": (34816, 5120),
    "27b_down": (5120, 17408),
    "27b_q": (12288, 5120),
    "35b_gate_up": (1024, 2048),
    "35b_down": (2048, 512),
    "smoke": (128, 128),
}


def dequant(packed, scales, multiplier):
    """Independent inverse of 128x4 SF layout; low nibble is first K value."""
    rows, kb = packed.shape
    k = kb * 2
    rp, kp = (rows + 127) // 128 * 128, (k // 16 + 3) // 4 * 4
    sf = scales.contiguous().view(torch.float8_e4m3fn).reshape(
        rp // 128, kp // 4, 32, 4, 4
    ).permute(0, 3, 2, 1, 4).reshape(rp, kp)[:rows, :k // 16].float()
    lut = torch.tensor(
        [0, .5, 1, 1.5, 2, 3, 4, 6, -0., -.5, -1, -1.5, -2, -3, -4, -6],
        device=packed.device, dtype=torch.float32,
    )
    p = packed.view(torch.uint8)
    vals = torch.stack((lut[(p & 15).long()], lut[(p >> 4).long()]), -1)
    return vals.reshape(rows, k) * sf.repeat_interleave(16, dim=1) / multiplier


def error(actual, expected):
    a, b = actual.float().flatten(), expected.float().flatten()
    delta = a - b
    return {"max_abs": delta.abs().max().item(),
            "relative_l2": (delta.norm() / b.norm().clamp_min(1e-30)).item(),
            "cosine": torch.nn.functional.cosine_similarity(a, b, dim=0).item(),
            "finite": bool(torch.isfinite(a).all().item())}


def timing(fn, iterations, repeats):
    for _ in range(5):
        fn()
    torch.cuda.synchronize()
    measurements = []
    for _ in range(repeats):
        start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(iterations):
            fn()
        end.record()
        end.synchronize()
        measurements.append(start.elapsed_time(end) * 1000 / iterations)
    return {"median_us": sorted(measurements)[len(measurements) // 2],
            "samples_us": measurements}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shapes", default="27b_gate,27b_down,27b_q,35b_gate_up,35b_down")
    ap.add_argument("--rows", default="1,2,4,5,16")
    ap.add_argument("--backends", default="cutlass,cudnn,b12x")
    ap.add_argument("--iterations", type=int, default=30)
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--output", type=Path)
    ap.add_argument("--autotune", action="store_true")
    args = ap.parse_args()
    logfile = None
    if args.output:
        args.output.mkdir(parents=True, exist_ok=True)
        logfile = (args.output / "results.jsonl").open("w")
    def emit(record):
        line = json.dumps(record)
        print(line, flush=True)
        if logfile:
            logfile.write(line + "\n")
            logfile.flush()
    torch.manual_seed(42)
    torch.backends.cuda.matmul.allow_tf32 = False
    emit({"kind": "environment", "torch": torch.__version__,
                      "cuda": torch.version.cuda, "flashinfer": fi.__version__,
                      "gpu": torch.cuda.get_device_name(),
                      "capability": torch.cuda.get_device_capability(),
                      "args": {key: str(value) if isinstance(value, Path) else value
                               for key, value in vars(args).items()}})
    for name in args.shapes.split(","):
        n, k = SHAPES[name]
        w = torch.randn((n, k), device="cuda", dtype=torch.bfloat16)
        wg = (2688 / w.float().abs().max()).reshape(1)
        wq, ws = fi.nvfp4_quantize(w, wg, sfLayout=fi.SfLayout.layout_128x4, do_shuffle=False)
        wd = dequant(wq, ws, wg)
        for m in map(int, args.rows.split(",")):
            x = torch.randn((m, k), device="cuda", dtype=torch.bfloat16)
            xg = (2688 / x.float().abs().max()).reshape(1)
            quant = lambda: fi.nvfp4_quantize(x, xg, sfLayout=fi.SfLayout.layout_128x4, do_shuffle=False)
            xq, xs = quant()
            alpha = 1 / (xg * wg)
            exact = dequant(xq, xs, xg) @ wd.T
            original = x.float() @ w.float().T
            baseline = measure(lambda: torch.mm(x, w.T), repeats=args.iterations)
            quant_time = measure(quant, repeats=args.iterations)
            for backend in args.backends.split(","):
                result = {"kind": "case", "shape": name, "m": m, "n": n, "k": k,
                          "backend": backend, "bf16": baseline, "activation_quant": quant_time,
                          "autotune": args.autotune}
                try:
                    out = torch.empty((m, n), dtype=torch.bfloat16, device="cuda")
                    def gemm(a=xq, s=xs):
                        return fi.mm_fp4(a, wq.T, s, ws.T, alpha, torch.bfloat16,
                                         out, backend=backend)
                    start = time.monotonic()
                    with fi.autotune(args.autotune):
                        gemm()
                    torch.cuda.synchronize()
                    result["prepare_seconds"] = time.monotonic() - start
                    result["same_quantized_operands"] = error(out, exact)
                    result["original_bf16_operands"] = error(out, original)
                    result["gemm"] = timing(gemm, args.iterations, args.repeats)
                    result["quant_plus_gemm"] = timing(lambda: gemm(*quant()), args.iterations, args.repeats)
                    result["gemm_individual"] = measure(gemm, repeats=args.iterations)
                    result["quant_plus_gemm_individual"] = measure(lambda: gemm(*quant()), repeats=args.iterations)
                    result["status"] = "ok"
                except Exception as exc:
                    result.update(status="error", error_type=type(exc).__name__, error=str(exc))
                emit(result)
        del w, wq, ws, wd
        gc.collect()
        torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
