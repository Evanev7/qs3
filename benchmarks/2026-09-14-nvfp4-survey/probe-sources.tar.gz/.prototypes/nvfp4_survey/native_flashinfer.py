"""Build and run the isolated native CUTLASS FP4 benchmark on sp10."""
import argparse
import json
import os
from pathlib import Path
import subprocess

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--prefill", action="store_true", help="Run bounded M128/512 dense-27B prefill cases")
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    fi = root / "3pty/flashinfer"
    includes = ["include", "3rdparty/cutlass/include", "3rdparty/cutlass/tools/util/include",
                "3rdparty/cccl/libcudacxx/include", "3rdparty/cccl/cub", "3rdparty/cccl/thrust",
                "csrc/nv_internal", "csrc/nv_internal/include"]
    command = ["nvcc", "-std=c++17", "-O3", "-gencode=arch=compute_121a,code=sm_121a",
               "--expt-relaxed-constexpr", "-DENABLE_BF16", "-DENABLE_FP4", "-DENABLE_FP8",
               "-DCUTLASS_ENABLE_GDC_FOR_SM100=1", *["-I" + str(fi / p) for p in includes],
               str(here / "flashinfer_native_compile.cu"), str(here / "flashinfer_native_bench.cu"),
               str(here / "flashinfer_native_quant.cu"),
               *[str(fi / "csrc/nv_internal/cpp/common" / (p + ".cpp"))
                 for p in ["envUtils", "logger", "stringUtils", "tllmException"]],
               "-o", str(args.output / "native_bench"), "-lcublas"]
    (args.output / "compile_command.json").write_text(json.dumps(command, indent=2) + "\n")
    subprocess.run(command, check=True)
    env = dict(os.environ)
    if args.prefill:
        env["QS3_NVFP4_PREFILL"] = "1"
    (args.output / "run_mode.json").write_text(json.dumps({
        "prefill": bool(env.get("QS3_NVFP4_PREFILL")),
        "iterations": 10 if env.get("QS3_NVFP4_PREFILL") else 50,
        "warmups": 2 if env.get("QS3_NVFP4_PREFILL") else 10,
    }, indent=2) + "\n")
    subprocess.run([str(args.output / "native_bench"), str(args.output)], env=env, check=True)

if __name__ == "__main__":
    main()
