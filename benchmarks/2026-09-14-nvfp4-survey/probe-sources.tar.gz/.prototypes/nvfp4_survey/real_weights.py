"""Probe actual cached NVFP4 projection tensors with synthetic BF16 inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
import traceback

import torch
import flashinfer as fi
from common import measure, metrics
from flashinfer_probe import dequant


class Snapshot:
    def __init__(self, path):
        self.path = path
        index = json.loads((path / "model.safetensors.index.json").read_text())
        self.headers = {}
        self.files = {}
        for shard in sorted(set(index["weight_map"].values())):
            f = (path / shard).open("rb")
            size, = struct.unpack("<Q", f.read(8))
            header = json.loads(f.read(size))
            self.files[shard] = f
            for name, info in header.items():
                if name != "__metadata__":
                    self.headers[name] = dict(**info, shard=shard, base=8+size)

    def data(self, name):
        info = self.headers[name]
        f = self.files[info["shard"]]
        start, end = info["data_offsets"]
        f.seek(info["base"] + start)
        raw = f.read(end-start)
        assert len(raw) == end-start
        return raw, info

    def scalar(self, name):
        raw, info = self.data(name)
        assert info["dtype"] == "F32" and len(raw) == 4
        return struct.unpack("<f", raw)[0]

    def tensor(self, name):
        raw, info = self.data(name)
        dtype = {"U8": torch.uint8, "F8_E4M3": torch.float8_e4m3fn,
                 "BF16": torch.bfloat16, "F32": torch.float32}[info["dtype"]]
        tensor = torch.frombuffer(bytearray(raw), dtype=dtype).reshape(info["shape"])
        return tensor.cuda(), hashlib.sha256(raw).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--backend", choices=("b12x", "marlin", "flashinfer"), required=True)
    p.add_argument("--rows", default="1,5,16")
    p.add_argument("--repeats", type=int, default=20)
    a = p.parse_args()
    a.output.mkdir(exist_ok=True, parents=True)
    path = Path("/hf/models--nvidia--Qwen3.6-35B-A3B-NVFP4/snapshots/6c7f09d4036e97393f82e9f9ecd1a5c35ca5ee92")
    snapshot = Snapshot(path)
    torch.manual_seed(9917)
    torch.backends.cuda.matmul.allow_tf32 = False
    pairs = []
    for layer in range(40):
        for expert in range(256):
            prefix = f"model.language_model.layers.{layer}.mlp.experts.{expert}."
            gs = snapshot.scalar(prefix + "gate_proj.weight_scale_2")
            us = snapshot.scalar(prefix + "up_proj.weight_scale_2")
            ga = snapshot.scalar(prefix + "gate_proj.input_scale")
            ua = snapshot.scalar(prefix + "up_proj.input_scale")
            if gs != us or ga != ua:
                pairs.append(dict(layer=layer, expert=expert, gate_weight=gs, up_weight=us,
                                  gate_input=ga, up_input=ua))
    metadata = dict(snapshot=str(path), config_sha256=hashlib.sha256((path / "config.json").read_bytes()).hexdigest(),
                    backend=a.backend, paired_experts_checked=40*256, unequal_gate_up_count=len(pairs),
                    unequal_gate_up_examples=pairs[:20], inputs="synthetic BF16, real packed checkpoint weights",
                    checkpoint_mlp_precision="W4A16_NVFP4; W4A4 is an alternative, not its requested activation precision")
    (a.output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata), flush=True)
    if a.backend == "b12x":
        vendor = Path(__file__).parent / "vendor/b12x"
        sys.path.insert(0, str(vendor))
        from b12x.gemm import blockscaled
        from b12x.gemm.blockscaled import _a16
        from b12x._lib.intrinsics import swizzle_block_scale
    elif a.backend == "marlin":
        from vllm.model_executor.layers.quantization.utils.marlin_utils_fp4 import prepare_fp4_layer_for_marlin, apply_fp4_marlin_linear

    cases = [(0, 0), (20, 7), (39, 255)]
    with (a.output / "results.jsonl").open("w") as journal:
        for layer, expert in cases:
            for projection in ("gate_proj", "up_proj", "down_proj"):
                name = f"model.language_model.layers.{layer}.mlp.experts.{expert}.{projection}"
                packed, whash = snapshot.tensor(name + ".weight")
                scales, shash = snapshot.tensor(name + ".weight_scale")
                wg = snapshot.scalar(name + ".weight_scale_2")
                ai = snapshot.scalar(name + ".input_scale")
                n, kb = packed.shape
                k = kb * 2
                r = torch.arange(n, device="cuda")[:, None]
                g = torch.arange(k//16, device="cuda")[None, :]
                offset = ((r//128*((k//16+3)//4)+g//4)*512+r%32*16+r//32%4*4+g%4)
                sf = torch.zeros(((n+127)//128)*((k//16+3)//4)*512, dtype=torch.uint8, device="cuda")
                sf[offset] = scales.view(torch.uint8)
                wd = dequant(packed, sf, 1/wg)
                if a.backend == "b12x":
                    weight = blockscaled.pack_weight(packed, sf, recipe="nvfp4",
                                                     global_scale=torch.tensor([wg], device="cuda"))
                elif a.backend == "marlin":
                    module = torch.nn.Module()
                    module.output_size_per_partition, module.input_size_per_partition = n, k
                    module.params_dtype = torch.bfloat16
                    module.weight = torch.nn.Parameter(packed, requires_grad=False)
                    module.weight_scale = torch.nn.Parameter(scales, requires_grad=False)
                    module.weight_global_scale = torch.nn.Parameter(torch.tensor([wg], device="cuda"), requires_grad=False)
                    prepare_fp4_layer_for_marlin(module)
                for m in map(int, a.rows.split(",")):
                    record = dict(name=name, n=n, k=k, m=m, weight_sha256=whash, scales_sha256=shash,
                                  weight_global=wg, input_scale=ai, backend=a.backend)
                    try:
                        x = torch.randn(m, k, dtype=torch.bfloat16, device="cuda")
                        expected = x.float() @ wd.T
                        if a.backend == "b12x":
                            config = (128,64,4)
                            scratch = torch.empty(max(blockscaled.workspace_size(weight,m,_config=config),_a16._layout(m,n,k,True)[-1]),dtype=torch.uint8,device="cuda")
                            out = torch.empty(m,n,dtype=torch.bfloat16,device="cuda")
                            fn = lambda: blockscaled.mm(x,weight,mode="a16",out=out,workspace=scratch,expected_m=m,_config=config)
                        elif a.backend == "marlin":
                            fn = lambda: apply_fp4_marlin_linear(input=x,weight=module.weight,weight_scale=module.weight_scale,
                                weight_global_scale=module.weight_global_scale,workspace=module.workspace,size_n=n,size_k=k)
                        else:
                            ag = torch.tensor([1/ai],device="cuda")
                            alpha = torch.tensor([ai*wg],device="cuda")
                            def fn():
                                xq,xs = fi.nvfp4_quantize(x,ag,sfLayout=fi.SfLayout.layout_128x4)
                                return fi.mm_fp4(xq,packed.T,xs,sf.T,alpha,torch.bfloat16,backend="cutlass")
                            xq,xs = fi.nvfp4_quantize(x,ag,sfLayout=fi.SfLayout.layout_128x4)
                            quantized_expected = dequant(xq,xs,ag) @ wd.T
                        actual = fn()
                        record["error_vs_w4a16"] = metrics(actual,expected)
                        checked = metrics(actual,quantized_expected) if a.backend == "flashinfer" else record["error_vs_w4a16"]
                        record["same_operand_error"] = checked
                        assert checked["finite"] and checked["relative_l2"] < .01, checked
                        record["timing"] = measure(fn,repeats=a.repeats)
                        record["status"] = "ok"
                    except Exception as error:
                        record.update(status="error",error=repr(error),traceback=traceback.format_exc())
                    line = json.dumps(record)
                    journal.write(line+"\n"); journal.flush()
                    print(line,flush=True)


if __name__ == "__main__":
    main()
