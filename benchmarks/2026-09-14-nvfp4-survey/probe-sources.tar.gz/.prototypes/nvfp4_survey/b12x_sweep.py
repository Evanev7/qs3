"""Graph-free dense A16 tile/split-K sweep at two real27B MLP shapes.

32 shape/config specializations, each evaluated at M1/5/16 (96 cases).
Weights/input/reference/storage are reused across configs; all timed outputs
must pass same-operand correctness and a post-timing poisoned-output check.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import itertools
import json
from pathlib import Path
import random
import time
import traceback

# This module also resolves prototype/vendor b12x before importing the package.
from b12x_probe import b12x, blockscaled, cutlass, quality, swizzle_block_scale, torch, unpack
from common import measure


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--rows", nargs="+", type=int, default=[1, 5, 16])
    p.add_argument("--shapes", nargs="+", choices=["up", "down"], default=["up", "down"])
    p.add_argument("--n-tiles", nargs="+", type=int, default=[64, 128])
    p.add_argument("--k-tiles", nargs="+", type=int, default=[64, 128])
    p.add_argument("--splits", nargs="+", type=int, default=[1, 2, 4, 8])
    p.add_argument("--iterations", type=int, default=12)
    p.add_argument("--flush-mib", type=int, default=128)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.manual_seed(1701)
    configs = list(itertools.product(args.n_tiles, args.k_tiles, args.splits))
    random.Random(175).shuffle(configs)
    report = dict(source=b12x.__file__, imported_cutlass=dict(path=cutlass.__file__, version=getattr(cutlass, "__version__", None)),
                  installed_dsl=importlib.metadata.version("nvidia-cutlass-dsl"),
                  torch=torch.__version__, gpu=torch.cuda.get_device_name(),
                  capability=torch.cuda.get_device_capability(), graphs=False,
                  precision="W4A16 with local BF16 weight reconstruction and separate global multiplier",
                  timing_scope="b12x blockscaled.mm A16 compute and optional split-K reduction; Python enqueue included",
                  config_order=configs, rows=args.rows, cases=[], summary=[])
    def save():
        (args.output / "b12x_sweep.json").write_text(json.dumps(report, indent=2)+"\n")
    save()
    with (args.output / "results.jsonl").open("w") as journal:
        for shape in args.shapes:
            n, k = (17408, 5120) if shape == "up" else (5120, 17408)
            packed = torch.randint(0, 256, (n, k//2), device="cuda", dtype=torch.uint8)
            scales = (torch.rand(n, k//16, device="cuda")*2+.0625).to(torch.float8_e4m3fn)
            storage = swizzle_block_scale(scales)
            global_scale = torch.tensor([.137], device="cuda", dtype=torch.float32)
            weight = blockscaled.pack_weight(packed, storage, recipe="nvfp4", global_scale=global_scale)
            decoded = (unpack(packed)*scales.float().repeat_interleave(16, 1)).bfloat16().float()
            inputs = {m: torch.randn(m, k, device="cuda", dtype=torch.bfloat16) for m in args.rows}
            references = {m: (x.float() @ decoded.T)*global_scale for m, x in inputs.items()}
            del decoded
            outputs = {m: torch.empty(m, n, device="cuda", dtype=torch.bfloat16) for m in args.rows}
            scratch = torch.empty(max(args.splits)*max(args.rows)*n*4, device="cuda", dtype=torch.uint8)
            for config in configs:
                for m in args.rows:
                    record = dict(shape=shape, n=n, k=k, m=m, config=config)
                    x, out = inputs[m], outputs[m]
                    def fn():
                        return blockscaled.mm(x, weight, mode="a16", out=out,
                                              workspace=scratch, expected_m=m, _config=config)
                    try:
                        start = time.monotonic()
                        fn()
                        torch.cuda.synchronize()
                        record["first_call_seconds"] = time.monotonic()-start
                        record["quality"] = quality(out, references[m])
                        record["timing"] = measure(fn, flush_bytes=args.flush_mib<<20, repeats=args.iterations)
                        out.fill_(float("nan"))
                        fn()
                        record["post_timing_quality"] = quality(out, references[m])
                        record["status"] = "ok"
                    except Exception as error:
                        record.update(status="error", error=repr(error), traceback=traceback.format_exc())
                    report["cases"].append(record)
                    line = json.dumps(record)
                    journal.write(line+"\n"); journal.flush()
                    print(line, flush=True)
                    save()
            for m in args.rows:
                passed = [r for r in report["cases"] if r["shape"] == shape and r["m"] == m and r["status"] == "ok"]
                passed.sort(key=lambda r: r["timing"]["evicted"]["median_us"])
                default = next((r for r in passed if tuple(r["config"]) == (128, 64, 4)), None)
                report["summary"].append(dict(shape=shape, m=m,
                    default_evicted_us=default["timing"]["evicted"]["median_us"] if default else None,
                    ranked=[dict(config=r["config"], evicted_us=r["timing"]["evicted"]["median_us"],
                                 warm_us=r["timing"]["warm"]["median_us"], relative_l2=r["quality"]["relative_l2"])
                            for r in passed]))
            save()
            del inputs, references, outputs, scratch, weight, packed, scales, storage
    print(json.dumps(report["summary"], indent=2), flush=True)


if __name__ == "__main__":
    main()
