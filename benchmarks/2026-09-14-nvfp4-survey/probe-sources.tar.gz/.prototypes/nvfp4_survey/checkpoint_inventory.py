"""Read cached Qwen checkpoint metadata without scanning weight payloads."""
import argparse
import collections
import json
from pathlib import Path
import struct

p = argparse.ArgumentParser()
p.add_argument("--output", type=Path, required=True)
a = p.parse_args()
reports = []
for snapshot in sorted(Path("/hf").glob("models--*/snapshots/*")):
    if "Qwen3." not in str(snapshot):
        continue
    index = snapshot / "model.safetensors.index.json"
    if not index.is_file():
        continue
    mapping = json.loads(index.read_text())["weight_map"]
    shards = sorted(set(mapping.values()))
    missing = [name for name in shards if not (snapshot / name).is_file()]
    report = dict(snapshot=str(snapshot), tensor_count=len(mapping), shards=len(shards), missing=missing)
    for name in ("config.json", "hf_quant_config.json", "quantize_config.json"):
        if (snapshot / name).is_file():
            report[name] = json.loads((snapshot / name).read_text())
    if "NVFP4" in str(snapshot).upper():
        headers = {}
        for shard in shards:
            path = snapshot / shard
            if not path.is_file():
                continue
            with path.open("rb") as f:
                size, = struct.unpack("<Q", f.read(8))
                header = json.loads(f.read(size))
            for name, metadata in header.items():
                if name == "__metadata__":
                    continue
                headers[name] = dict(**metadata, shard=shard, payload_offset=8+size)
        report["dtype_counts"] = dict(collections.Counter(info["dtype"] for info in headers.values()))
        report["selected_tensors"] = {name: info for name, info in headers.items()
            if ("layers.0." in name and ("experts." not in name or "experts.0." in name))
            or name.endswith("lm_head.weight") or name.startswith("mtp.fc")}
        (a.output / (snapshot.parent.parent.name + "-headers.json")).write_text(json.dumps(headers) + "\n")
    reports.append(report)
(a.output / "checkpoints.json").write_text(json.dumps(reports, indent=2) + "\n")
for report in reports:
    print(json.dumps({k: v for k, v in report.items() if k not in ("config.json", "selected_tensors")}), flush=True)
