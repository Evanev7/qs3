"""One complete cached35B layer0 routed MoE: native checkpoint W4A16 math.

Real E256 expert weights/scales, synthetic BF16 inputs and supplied top8 routes.
Both projections, SiLU, internal routing and weighted reduction are timed.
No full-model load, router projection/topk selection, shared expert, or graphs.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import time
import traceback

import moe_probe  # resolves the isolated vendored b12x package path
import torch
import b12x
import cutlass
from b12x._lib.intrinsics import swizzle_block_scale
from b12x.moe import fused_moe
from b12x.policy import MOE_DECODE, get_auto_policy
from tests._reference.w4a16_reference import moe_reference_w4a16
from real_weights import Snapshot
from common import measure, metrics

REV = "6c7f09d4036e97393f82e9f9ecd1a5c35ca5ee92"
SNAPSHOT = Path("/hf/models--nvidia--Qwen3.6-35B-A3B-NVFP4/snapshots") / REV
E, H, I, TOPK = 256, 2048, 512, 8


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--rows", nargs="+", type=int, default=[1, 5, 16])
    p.add_argument("--routing", nargs="+", choices=["diverse", "shared"], default=["diverse", "shared"])
    p.add_argument("--iterations", type=int, default=20)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.backends.cuda.matmul.allow_tf32 = False
    device = torch.device("cuda", 0)
    torch.cuda.set_device(device)
    report = dict(snapshot=str(SNAPSHOT), revision=REV, layer=0, precision="W4A16_NVFP4",
                  source=b12x.__file__, imported_cutlass=dict(path=cutlass.__file__, version=getattr(cutlass,"__version__",None)),
                  gpu=torch.cuda.get_device_name(), capability=torch.cuda.get_device_capability(),
                  geometry=dict(experts=E, hidden=H, intermediate=I, topk=TOPK), graphs=False,
                  inputs="synthetic BF16; native cached checkpoint weights", w13_order="up,gate",
                  timing_scope="internal routes + gate/up + SiLU + down + weighted reduction; supplied topk IDs/weights",
                  cases=[], tensors={})
    def save():
        (args.output / "real_moe.json").write_text(json.dumps(report, indent=2)+"\n")
    save()
    started = time.monotonic()
    try:
        raw_config = (SNAPSHOT / "config.json").read_bytes()
        report["config_sha256"] = hashlib.sha256(raw_config).hexdigest()
        cfg = json.loads(raw_config)
        assert cfg["quantization_config"]["quantized_layers"]["model.language_model.layers.0.mlp.experts"]["quant_algo"] == "W4A16_NVFP4"
        snapshot = Snapshot(SNAPSHOT)
        def load(name, shape, dtype):
            tensor, digest = snapshot.tensor(name)
            assert tuple(tensor.shape) == shape and tensor.dtype == dtype, (name, tensor.shape, tensor.dtype)
            report["tensors"][name] = dict(sha256=digest, shape=shape, dtype=str(dtype))
            return tensor
        def scalar(name):
            value = snapshot.scalar(name)
            assert math.isfinite(value) and value > 0, (name, value)
            raw, info = snapshot.data(name)
            report["tensors"][name] = dict(sha256=hashlib.sha256(raw).hexdigest(), value=value, dtype=info["dtype"])
            return value
        w13 = torch.empty((E, 2*I, H//2), device=device, dtype=torch.uint8)
        w2 = torch.empty((E, H, I//2), device=device, dtype=torch.uint8)
        sf13 = torch.empty((E, 2*I, H//16), device=device, dtype=torch.uint8)
        sf2 = torch.empty((E, H, I//16), device=device, dtype=torch.uint8)
        globals13, globals2, inputs, intermediates = [], [], [], []
        for expert in range(E):
            prefix = f"model.language_model.layers.0.mlp.experts.{expert}."
            gate_global = scalar(prefix+"gate_proj.weight_scale_2")
            up_global = scalar(prefix+"up_proj.weight_scale_2")
            gate_input = scalar(prefix+"gate_proj.input_scale")
            up_input = scalar(prefix+"up_proj.input_scale")
            assert gate_global == up_global, f"expert {expert}: unequal gate/up weight globals"
            assert gate_input == up_input, f"expert {expert}: unequal gate/up activation scales"
            globals13.append(gate_global)
            globals2.append(scalar(prefix+"down_proj.weight_scale_2"))
            inputs.append(1/gate_input)  # AUTO representation retains A4 metadata; A16 doesn't quantize inputs.
            intermediates.append(1/scalar(prefix+"down_proj.input_scale"))
            for proj, begin in (("up_proj", 0), ("gate_proj", I)):
                w13[expert, begin:begin+I].copy_(load(prefix+proj+".weight", (I,H//2), torch.uint8))
                sf13[expert, begin:begin+I].copy_(load(prefix+proj+".weight_scale", (I,H//16), torch.float8_e4m3fn).view(torch.uint8))
            w2[expert].copy_(load(prefix+"down_proj.weight", (H,I//2), torch.uint8))
            sf2[expert].copy_(load(prefix+"down_proj.weight_scale", (H,I//16), torch.float8_e4m3fn).view(torch.uint8))
        for f in snapshot.files.values():
            f.close()
        weights = fused_moe.PackedWeights(
            w13=w13, w2=w2,
            w13_block_scales=swizzle_block_scale(sf13.view(torch.float8_e4m3fn)),
            w2_block_scales=swizzle_block_scale(sf2.view(torch.float8_e4m3fn)),
            w13_global_scales=torch.tensor(globals13, device=device, dtype=torch.float32),
            w2_global_scales=torch.tensor(globals2, device=device, dtype=torch.float32),
            input_scale=torch.tensor(inputs, device=device, dtype=torch.float32),
            intermediate_scale=torch.tensor(intermediates, device=device, dtype=torch.float32))
        del sf13, sf2
        weight_plan = fused_moe.plan_weights(
            source=fused_moe.PackedSource(format="modelopt_nvfp4", w13_layout="w13"),
            geometry=fused_moe.MoEGeometry(num_experts=E, hidden_size=H, intermediate_size=I),
            activation=fused_moe.ActivationSpec(mode=fused_moe.ActivationMode.AUTO, nonlinearity="silu", io_dtype=torch.bfloat16),
            constraints=fused_moe.WeightPlanConstraints(required_packing=fused_moe.WeightPacking.SOURCE_NATIVE))
        experts = fused_moe.prepare_weights(plan=weight_plan, weights=weights)
        native = experts._impl.representation_for("w4a16")
        for original, prepared in ((w13,native.w13),(w2,native.w2),
                                   (weights.w13_block_scales,native.w13_scale),(weights.w2_block_scales,native.w2_scale)):
            assert original.data_ptr() == prepared.data_ptr()
        torch.cuda.synchronize()
        report.update(weight_setup_seconds=time.monotonic()-started, paired_experts_checked=E,
                      unequal_gate_up_count=0, native_payload_shared=True,
                      weight_global13_range=[min(globals13),max(globals13)],
                      weight_global2_range=[min(globals2),max(globals2)])
        save()
    except Exception as error:
        report.update(setup_error=repr(error), traceback=traceback.format_exc())
        save()
        raise
    plans = {}
    with (args.output / "results.jsonl").open("w") as journal:
        for routing in args.routing:
            for m in args.rows:
                case = dict(routing=routing, m=m)
                report["cases"].append(case)
                try:
                    small = m <= 8
                    config = fused_moe.MoeDecodeConfig(backend="w4a16", route_planner="internal", max_active_clusters=None,
                                                       w4a16_route_mode="direct" if small else "packed")
                    group_rows = tuple(row for row in args.rows if (row <= 8) == small)
                    key = max(group_rows)
                    if key not in plans:
                        started = time.monotonic()
                        plan = fused_moe.plan_execution(experts=experts,
                            capacity=fused_moe.ExecutionCapacity(max_tokens=key, top_k=TOPK, warmup_token_counts=group_rows),
                            policy=get_auto_policy(device).with_override(MOE_DECODE,config))
                        fused_moe.prewarm(plan)
                        spec, = plan.scratch_specs()
                        scratch = torch.empty(spec.shape, dtype=spec.dtype, device=device)
                        torch.cuda.synchronize()
                        plans[key] = plan,scratch
                        case["plan_seconds"] = time.monotonic()-started
                    plan,scratch = plans[key]
                    torch.manual_seed(9900+m)
                    x = torch.randn(m,H,device=device,dtype=torch.bfloat16)
                    base = torch.arange(TOPK,device=device,dtype=torch.int32)[None,:]*29
                    token = torch.arange(m,device=device,dtype=torch.int32)[:,None]
                    ids = ((base+token*(11 if routing=="diverse" else 0))%E).expand(m,TOPK).contiguous()
                    routes = torch.softmax(torch.randn(m,TOPK,device=device),dim=-1)
                    output = torch.full_like(x,float("nan"))
                    binding = fused_moe.bind(plan,scratch=scratch,a=x,experts=experts,topk_ids=ids,
                                             topk_weights=routes,output=output,input_scales_static=True)
                    def run():
                        fused_moe.run(binding=binding)
                    expected = moe_reference_w4a16(x,w13,weights.w13_block_scales,weights.w13_global_scales,
                                                   w2,weights.w2_block_scales,weights.w2_global_scales,
                                                   ids,routes,E,H,I)
                    assert bool(torch.isfinite(expected).all()) and bool(expected.count_nonzero())
                    def check():
                        quality = metrics(output,expected)
                        assert quality["finite"] and bool(output.count_nonzero()) and quality["cosine"]>=.9975 and quality["relative_l2"]<=.08, quality
                        return quality
                    run()
                    case["quality"] = check()
                    case["config"] = vars(config)
                    case["unique_experts"] = int(ids.unique().numel())
                    case["timing"] = measure(run,flush_bytes=128<<20,repeats=args.iterations)
                    output.fill_(float("nan"));run()
                    case["post_timing_quality"] = check()
                    case["status"] = "ok"
                except Exception as error:
                    case.update(status="error",error=repr(error),traceback=traceback.format_exc())
                line=json.dumps(case)
                journal.write(line+"\n");journal.flush()
                print(line,flush=True)
                save()


if __name__ == "__main__":
    main()
