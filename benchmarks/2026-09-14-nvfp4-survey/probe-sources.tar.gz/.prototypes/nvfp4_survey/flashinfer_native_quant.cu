// AOT specialization of FlashInfer's small-M BF16 -> NVFP4 kernel.
#include "tensorrt_llm/kernels/quantization.cuh"
extern "C" void qs3_probe_quant(const __nv_bfloat16* input,void* packed,void* scales,
                                 const float* global,int m,int k,int sm_count,cudaStream_t stream){
  using namespace tensorrt_llm;
  using namespace tensorrt_llm::kernels;
  int block=std::min(k/CVT_FP16_TO_FP4_ELTS_PER_THREAD,512);
  int grid=std::min((m+127)/128*128,sm_count*std::max(1,2048/block));
  quantize_with_block_size<BlockScaleQuantizationType::FP16_TO_FP4,__nv_bfloat16,16,false>
    <<<grid,block,0,stream>>>(1,m,k,k,input,global,packed,(uint32_t*)scales,QuantizationSFLayout::SWIZZLED_128x4);
}
