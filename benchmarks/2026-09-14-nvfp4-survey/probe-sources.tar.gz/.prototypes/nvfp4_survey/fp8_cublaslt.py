import argparse
import json
from pathlib import Path
import subprocess
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,required=True);args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    command=["nvcc","-std=c++17","-O3","-gencode=arch=compute_121a,code=sm_121a",
             str(Path(__file__).with_suffix(".cu")),"-o",str(args.output/"fp8_probe"),"-lcublasLt","-lcublas"]
    (args.output/"compile_command.json").write_text(json.dumps(command,indent=2)+"\n")
    subprocess.run(command,check=True);subprocess.run([str(args.output/"fp8_probe"),str(args.output)],check=True)
if __name__=="__main__":main()
