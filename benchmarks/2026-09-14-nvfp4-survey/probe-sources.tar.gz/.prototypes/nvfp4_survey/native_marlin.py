"""Python prepares weights; a standalone native .so owns all timed launches."""
import argparse
import ctypes
import json
from pathlib import Path
import subprocess
import torch
from common import metrics

def fixture(rows,k,seed):
    # Identical hash/codes/scales to native FI and Triton fixtures.
    pair=torch.arange(rows*k//2,device="cuda",dtype=torch.int64)
    h=pair^(seed*0x9e3779b9&0xffffffff);h=h^(h>>16);h=h*0x7feb352d&0xffffffff;h=h^(h>>15);h=h*0x846ca68b&0xffffffff;h=h^(h>>16)
    packed=((h&15)|(((h>>8)&15)<<4)).to(torch.uint8).reshape(rows,k//2)
    r=torch.arange(rows,device="cuda")[:,None];s=torch.arange(k//16,device="cuda")[None,:]
    scales=(0x30+((r*3+s*5+seed)&7)).to(torch.uint8).view(torch.float8_e4m3fn)
    lut=torch.tensor([0,.5,1,1.5,2,3,4,6,-0.,-.5,-1,-1.5,-2,-3,-4,-6],device="cuda")
    dense=torch.stack((lut[(packed&15).long()],lut[(packed>>4).long()]),-1).reshape(rows,k)*scales.float().repeat_interleave(16,1)
    return packed,scales,dense.to(torch.bfloat16)

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--output",type=Path,required=True);args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    here=Path(__file__).resolve().parent;root=here.parents[1];vllm=root/"3pty/vllm/csrc"
    libpath=args.output/"marlin_native.so"
    command=["nvcc","-std=c++17","-O3","--expt-relaxed-constexpr","-gencode=arch=compute_121a,code=sm_121a","-shared","-Xcompiler=-fPIC","-I"+str(here/"marlin_native/shim"),"-I"+str(vllm),"-I"+str(vllm/"libtorch_stable/quantization/marlin"),str(here/"marlin_native/bench.cu"),"-o",str(libpath)]
    (args.output/"compile_command.json").write_text(json.dumps(command,indent=2)+"\n");subprocess.run(command,check=True)
    from vllm.model_executor.layers.quantization.utils.marlin_utils_fp4 import prepare_fp4_layer_for_marlin
    lib=ctypes.CDLL(str(libpath));fn=lib.marlin_bench;fn.argtypes=[ctypes.c_void_p]*5+[ctypes.c_int]*4+[ctypes.POINTER(ctypes.c_double)];fn.restype=ctypes.c_int
    torch.backends.cuda.matmul.allow_tf32=False
    with (args.output/"results.jsonl").open("w") as log:
      for n,k in [(17408,5120),(5120,17408),(10240,5120),(1024,2048),(2048,512)]:
        packed,scales,wd=fixture(n,k,17);layer=torch.nn.Module();layer.output_size_per_partition=n;layer.input_size_per_partition=k;layer.params_dtype=torch.bfloat16
        layer.weight=torch.nn.Parameter(packed,requires_grad=False);layer.weight_scale=torch.nn.Parameter(scales,requires_grad=False);layer.weight_global_scale=torch.nn.Parameter(torch.ones(1,device="cuda"),requires_grad=False);prepare_fp4_layer_for_marlin(layer)
        for m in [1,2,4,5,16]:
          _,_,x=fixture(m,k,3);reference=x.float()@wd.float().T;y=torch.empty((m,n),device="cuda",dtype=torch.bfloat16);torch.cuda.synchronize()
          for tactic in [0,1]:
            times=(ctypes.c_double*6)();status=fn(x.data_ptr(),layer.weight.data_ptr(),y.data_ptr(),layer.weight_scale.data_ptr(),layer.weight_global_scale.data_ptr(),m,n,k,tactic,times)
            result=dict(m=m,n=n,k=k,tactic=tactic,status=status,native_times_us=list(times),same_quantized_weights=metrics(y,reference))
            line=json.dumps(result);print(line,flush=True);log.write(line+"\n");log.flush()
            if status or result["same_quantized_weights"]["relative_l2"]>.005:raise RuntimeError("native Marlin correctness failed")
if __name__=="__main__":main()
