"""Run the Triton AOT/native-driver probe using the build-tools environment."""
import datetime
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import sys

here = Path(__file__).resolve().parent
prototypes = here.parent
repo = prototypes.parent
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
output = Path(tempfile.mkdtemp(prefix=f"nvfp4-triton-{stamp}-", dir=prototypes / "out"))
shutil.copytree(here / "triton_aot", output / "source", ignore=shutil.ignore_patterns("out", "__pycache__"))
command = [str(repo / "build_tools/.venv/bin/python"), str(here / "triton_aot/run.py"), "--output", str(output), *sys.argv[1:]]
(output / "command.json").write_text(json.dumps(command, indent=2) + "\n")
print(f"Triton AOT probe: {output}", flush=True)
with (output / "run.log").open("w") as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
print((output / "run.log").read_text()[-12000:], flush=True)
(output / "exit.json").write_text(json.dumps({"returncode": result.returncode}) + "\n")
