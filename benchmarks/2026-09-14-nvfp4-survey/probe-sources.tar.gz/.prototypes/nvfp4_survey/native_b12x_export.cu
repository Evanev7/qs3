// Links the actual CuTe export objects, including their generated TMA host code.
#include <cuda_runtime.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <vector>
#define CUTE_DSL_CUDA_ERROR_CHECK(e) do{cudaError_t status=(e);if(status!=cudaSuccess){fprintf(stderr,"export load: %s\n",cudaGetErrorString(status));std::abort();}}while(0)
#include "qs3_b12x_densegemmlaunch_0.h"
#include "qs3_b12x_densesplitkreduce_1.h"
#define CK(e) do{cudaError_t status=(e);if(status!=cudaSuccess){fprintf(stderr,"%s: %s\n",#e,cudaGetErrorString(status));return int(status);}}while(0)
__global__ void evict(unsigned* p,size_t n){size_t i=blockIdx.x*blockDim.x+threadIdx.x;if(i<n)p[i]++;}
extern "C" int b12x_export_bench(void* x,void* weight,void* scales,void* alpha,void* output,int m,double* times){
 static qs3_b12x_densegemmlaunch_0_Kernel_Module_t gemm_module;
 static qs3_b12x_densesplitkreduce_1_Kernel_Module_t reduce_module;
 static bool loaded=false;
 if(!loaded){qs3_b12x_densegemmlaunch_0_Kernel_Module_Load(&gemm_module);qs3_b12x_densesplitkreduce_1_Kernel_Module_Load(&reduce_module);loaded=true;}
 void *partial,*cache;CK(cudaMalloc(&partial,size_t(4)*m*17408*4));CK(cudaMalloc(&cache,128<<20));CK(cudaMemset(cache,0,128<<20));
 auto launch=[&](){
  // Unused quantized-output operands match the upstream wrapper's aligned sentinel.
  int status=cute_dsl_qs3_b12x_densegemmlaunch_0_wrapper(&gemm_module,x,weight,scales,scales,partial,(void*)16,(void*)16,(void*)16,alpha,m,nullptr);
  if(status)return status;
  return int(cute_dsl_qs3_b12x_densesplitkreduce_1_wrapper(&reduce_module,partial,output,m,nullptr));
 };
 for(int i=0;i<10;i++){int status=launch();if(status)return status;}CK(cudaDeviceSynchronize());
 cudaEvent_t a,b;CK(cudaEventCreate(&a));CK(cudaEventCreate(&b));
 for(int trial=0;trial<3;trial++)for(int cold=0;cold<2;cold++){
  std::vector<float> samples;for(int i=0;i<50;i++){
   if(cold)evict<<<((128<<20)/4+255)/256,256>>>((unsigned*)cache,(128<<20)/4);
   CK(cudaEventRecord(a));int status=launch();if(status)return status;CK(cudaEventRecord(b));CK(cudaEventSynchronize(b));float ms;CK(cudaEventElapsedTime(&ms,a,b));samples.push_back(ms*1000);
  }std::sort(samples.begin(),samples.end());times[trial*2+cold]=samples[samples.size()/2];
 }
 CK(cudaEventDestroy(a));CK(cudaEventDestroy(b));CK(cudaFree(cache));CK(cudaFree(partial));return 0;
}
