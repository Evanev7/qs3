"""Compare packed MoE routing against direct chunks at M1/5/16, A16 only.

Native direct decode supports at most8 tokens. M16 direct-chunks therefore
executes two M8 MoE calls, with all calls included in each measured interval.
Repeated hot8 routes model maximum expert overlap; diverse routes spread work.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--rows", nargs="+", type=int, default=[1, 5, 16])
    p.add_argument("--iterations", type=int, default=20)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    summary = dict(precision="A16", graphs=False, direct_capacity=8,
                   timing_scope="complete MoE, including all direct chunk calls; no router projection/topk selection",
                   runs=[], comparisons=[])
    helper = Path(__file__).parent / "moe_probe.py"
    for routing in ("diverse", "shared"):
        for mode in ("packed", "chunked-direct"):
            output = args.output / f"{routing}-{mode}"
            output.mkdir(exist_ok=True)
            command = [sys.executable, str(helper), "--output", str(output),
                       "--worker-mode", "a16", "--routing", routing,
                       "--a16-route-mode", mode, "--iterations", str(args.iterations),
                       "--rows", *map(str, args.rows)]
            with (output / "run.log").open("w") as log:
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
            row = dict(routing=routing, route_mode=mode, returncode=result.returncode, command=command)
            if (output / "moe.json").exists():
                row["report"] = json.loads((output / "moe.json").read_text())
                for case in row["report"].get("cases", []):
                    summary["comparisons"].append(dict(
                        routing=routing, route_mode=mode, m=case["m"],
                        passed=case.get("correctness_passed", False) and case.get("post_timing_passed", False),
                        unique_experts=case.get("unique_experts"), calls=case.get("moe_calls_per_iteration"),
                        evicted_us=case.get("timing", {}).get("evicted", {}).get("median_us"),
                        warm_us=case.get("timing", {}).get("warm", {}).get("median_us"),
                        error=case.get("error")))
            summary["runs"].append(row)
            (args.output / "moe_routing_sweep.json").write_text(json.dumps(summary, indent=2)+"\n")
            print((output / "run.log").read_text()[-5000:], flush=True)
    print(json.dumps(summary["comparisons"], indent=2), flush=True)


if __name__ == "__main__":
    main()
