#!/usr/bin/env python3
"""FlashInfer BF16 x NVFP4 providers, preserving BF16 activation inputs."""
import argparse
import json
from pathlib import Path
import torch
import flashinfer as fi
from common import measure, metrics
from flashinfer_probe import SHAPES, dequant

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--output",type=Path,required=True)
    ap.add_argument("--shapes",default="27b_gate,27b_down,27b_q,35b_gate_up,35b_down")
    ap.add_argument("--rows",default="1,2,4,5,16")
    ap.add_argument("--backends",default="cudnn,cute-dsl")
    ap.add_argument("--repeats",type=int,default=30)
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    torch.manual_seed(42);torch.backends.cuda.matmul.allow_tf32=False
    with (args.output/"results.jsonl").open("w") as log:
        def emit(record):
            s=json.dumps(record);print(s,flush=True);log.write(s+"\n");log.flush()
        for name in args.shapes.split(","):
            n,k=SHAPES[name]
            w=torch.randn((n,k),device="cuda",dtype=torch.bfloat16)
            wg=(2688/w.float().abs().max()).reshape(1)
            wq,ws=fi.nvfp4_quantize(w,wg,sfLayout=fi.SfLayout.layout_128x4)
            wd=dequant(wq,ws,wg)
            for backend in args.backends.split(","):
                try:
                    wp,sp,alpha=fi.prepare_bf16_fp4_weights(wq,ws,1/wg,backend=backend)
                    for m in map(int,args.rows.split(",")):
                        x=torch.randn((m,k),device="cuda",dtype=torch.bfloat16)
                        out=torch.empty((m,n),device="cuda",dtype=torch.bfloat16)
                        fn=lambda:fi.mm_bf16_fp4(x,wp,sp,alpha,backend=backend,out=out)
                        y=fn()
                        emit(dict(status="ok",backend="flashinfer_w4a16_"+backend,shape=name,m=m,n=n,k=k,
                                  same_quantized_weights=metrics(y,x.float()@wd.T),
                                  original_bf16_operands=metrics(y,x.float()@w.float().T),
                                  gemm=measure(fn,repeats=args.repeats),
                                  bf16=measure(lambda:x@w.T,repeats=args.repeats)))
                except Exception as exc:
                    emit(dict(status="error",backend=backend,shape=name,error_type=type(exc).__name__,error=str(exc)))

if __name__=="__main__":main()
