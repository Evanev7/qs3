"""Ensure pinned model metadata is cached, independently of bulk shard downloads."""
import json
import os
from pathlib import Path
import subprocess
from host import IMAGE

here=Path(__file__).resolve().parent
pins=json.loads((here/'download-pins.json').read_text())
hub=Path.home()/'.cache/huggingface/hub'
code='''import json,sys\nfrom huggingface_hub import snapshot_download\nfor item in json.loads(sys.argv[1]):\n    path=snapshot_download(item['repo'],revision=item['rev'],cache_dir='/hf',allow_patterns=['*.json','*.jinja','*.txt','*.model','*.tiktoken'],max_workers=4)\n    print(json.dumps({'repo':item['repo'],'rev':item['rev'],'metadata_snapshot':path}),flush=True)\n'''
subprocess.run(['docker','run','--rm','--network=bridge','--user',f'{os.getuid()}:{os.getgid()}',
                '-e','HF_HOME=/tmp/hf-home','-e','HF_HUB_CACHE=/hf','-v',f'{hub}:/hf',
                '--entrypoint','python3',IMAGE,'-c',code,json.dumps(pins)],check=True)
