# vLLM correctness capture

Run from the repository root, when the disposable GPU checkout is idle:

```sh
./remote.sh prototype vllm-correctness
```

This captures Qwen3.6-35B-A3B, Qwen3.6-27B, and Qwen3.8-27B sequentially.
Pins and expected text configs come from `models/<name>/source.nix` and
`model.json`; the collector checks the snapshot revision, text config, and
addressable tokenizer IDs before loading. Each model runs in its own instance
of the pinned container, loading once for a four-token smoke prompt and
102/32, 500/200, and 4000/800.
The container exits before loading the next model to release GPU memory.
This is an instrumented correctness run, separate from the core benchmark.
No runtime dependencies are added to the build-tools venv.

To capture just one model:

```sh
./remote.sh prototype vllm-correctness-35b
./remote.sh prototype vllm-correctness-36-27b
./remote.sh prototype vllm-correctness-38-27b
```

Run these sequentially. All selected snapshots must already be downloaded in
the default Hugging Face cache (or `HF_HUB_CACHE` / `HF_HOME` on the GPU host).
The runner checks metadata files and indexed weight shards before any GPU work;
missing snapshots produce the pinned `hf download` command. It does not download
weights or change the pinned container. The default image reference is in
`image.txt`, also used by the core vLLM benchmark recipe; `--image` overrides
it for qualification. A real capture resolves
the image once to its immutable Docker image ID and uses that ID for every
model, recording both the requested reference and full image inspection.
To inspect selections and commands locally:

```sh
python3 .prototypes/vllm_correctness/run.py --dry-run
```

Resume an interrupted capture from the same run directory with
`python3 .prototypes/vllm_correctness/run.py --resume .prototypes/out/vllm-correctness-RUN`.
The image ID, selected models and their full pins/configs must match. A model
is retained only when both the run's completed list and its success marker
agree; incomplete data and logs move intact into `failed/`. Each resume saves
the current collector/runner and image metadata in `resume-history/`. Completed
model captures retain their original collector copies and are not regenerated.

After retrieving a completed run, verify every raw row's size and hash and
cross-check the source, image, model pins, replay IDs, journals and small
reference summaries:

```sh
python3 .prototypes/vllm_correctness/verify.py \
  --run-dir .prototypes/out/vllm-correctness-RUN \
  --output .prototypes/out/vllm-correctness-RUN/verification.json \
  --export-dir benchmarks/vllm-reference-RUN
```

The export directory must be new and outside the raw run. It retains compact
metadata, workload inputs/scores/journals, small references, original and resumed
capture sources, image inspection and a complete file-hash manifest. Full logit
rows and `tokenizer.json` payloads remain in the original artifact; their sizes
and hashes are retained in `verified-files.json`, and the export's `.gitignore`
excludes them. Verification reads every original row before exporting. It checks
artifact consistency; it does not recompute top-k or compare qs3 outputs with
vLLM. The compact export alone cannot repeat full verification without the
omitted payloads.

The collector explicitly selects model runner v1 with
`VLLM_USE_V2_MODEL_RUNNER=0`. This keeps `compute_logits` outside the captured
model forward and callable from the Python hook when using vLLM 0.29, which
otherwise defaults to model runner v2. Model execution may still use CUDA
graphs; this instrumented collection does not measure performance.

`references/102-32.json` and `references/500-200.json` are copies of the original
results from `out/vllm-2026-09-13T103506Z-AIU8cb/`. They live outside `out/` so the
prototype upload includes them. The collector validates the model, prompt
fingerprint, precision, recurrent-state dtype, and token counts before loading.
These references apply only to 35B. Their continuations are forced, so comparisons
stay on the original benchmark prefix even if a fresh vLLM run would choose
another token. The 35B 4000/800 case and all 27B cases choose their own greedy
continuations, which are saved for subsequent forced-prefix replay. Supplying
these 35B references for a 27B capture is rejected. All prompts repeat/truncate
the fixed 102-token benchmark prompt; these are regression workloads, not quality tests.
The current correctness focus is 500/200; short and long cases are retained.
The core benchmark separately uses 102/32 and 1024/256.

The `4-4` workload uses prompt IDs `[1, 2, 3, 4]` and records four greedy
predictions: prefill and three decode forwards, without warmup. It uses each
model's own continuation. This matches the small prompt in
`src/loader/tests/mod.rs::real_qwen36_bf16_generates_reference_tokens`; that test's
existing 35B token/top-logit constants are not automatically replaced. These
are real-model raw-logit references, separate from the synthetic composition
fixtures generated by `qwen36_vectors`. Each model's `small-reference.json`
summarizes the four predictions, top-eight values/IDs and hashes/paths of the
full rows, together with the model revision, image ID and package versions.

Outputs are under `out/vllm-correctness-*/data/<model-name>/`, where model names
are `qwen3.6-35b-a3b`, `qwen3.6-27b`, and `qwen3.8-27b`. The run root records the
selected models, exported pins/configs, container commands, image/driver identity,
and a separate log per model. Root `SUCCESS.json` requires every selected model
to finish; each model also records workload progress and its own success marker.
Within each model directory:

- `metadata.json`: package versions, engine options and resolved configuration,
  GPU, recurrent-state precision, model name/repository, snapshot revision, and
  model/tokenizer hashes. `model-spec.json` retains the exported source/config.
- Copies of the collector, model/tokenizer configuration, base prompt IDs, and
  supplied reference results make the run self-describing.
- `<context>-<samples>/input.json`: exact prompt and forced continuation IDs,
  plus capture positions; accepts the existing `same_prefix_scores/qs3_test.rs`
  input format.
- `<context>-<samples>/vllm/logits-NNNN.f32`: one full, unmodified logit row,
  248320 little-endian FP32 values. Addressable IDs total 248070 for 3.6
  and 248077 for 3.8, checked against each pinned tokenizer. Casting BF16 logits to FP32 for storage does
  not restore precision; the original output dtype is recorded per row.
- `vllm/scores.json`: row hashes, top-20 IDs/logits, top-two margins, raw argmax,
  selected IDs, logsumexp, forced-token NLL, and differences from the original
  greedy continuation. Logsumexp/NLL use the full padded vocabulary to match the
  existing diagnostic; `addressable_logsumexp` separately excludes padded IDs.
- `vllm/records.jsonl` is written incrementally for interrupted-run inspection.
  `completed.json` lists finished workloads; `SUCCESS.json` exists only after
  collection finishes. The collector refuses to overwrite an existing output directory.

Step 0 predicts the first output immediately after prefill. Step N observes
`prompt_ids + forced_ids[:N]`. Each workload captures `samples + 4 + 1` rows:
prefill, four benchmark warmup decode forwards, and all measured decode forwards.
That is 37, 205, and 805 rows for the three benchmark workloads, plus four rows
for `4-4` (about 1.04 GB per model, 3.13 GB for all three).
The final predicted token is recorded but not fed back. All earlier tokens are in `input.json/forced_ids`.

The existing `qs3-correctness` recipe still replays its original saved 35B run;
it does not automatically select these new captures or build a 27B engine.
To compare a new capture, build qs3 for the corresponding model, set
`QS3_QWEN36_MODEL_DIR` to that exact snapshot, and feed a workload's `input.json`
to the existing score diagnostic. Put its output in the sibling `qs3/` directory. Then run:

```sh
python3 .prototypes/same_prefix_scores/compare.py \
  .prototypes/out/vllm-correctness-RUN/data/qwen3.6-27b/500-200
```

The hook captures `compute_logits` output before sampler processing and then
forces only the selected token. This preserves incremental GDN/KV updates.
Graph execution is enabled with shared maximum length 4805, which can change
vLLM's compiled choices relative to the standalone benchmark. The metadata and
original-continuation mismatch list make those differences visible. Capturing
logits synchronizes and writes files; none of these durations measure inference
performance. There are no intermediate layer-activation dumps.

Adding non-greedy sampling does not invalidate these raw-logit fixtures. Replay
the saved prefixes for model correctness, and apply penalties/temperature/
filtering to the saved rows for separate sampler tests. A shared RNG seed alone
does not guarantee identical output sequences across sampler implementations.

## Reading the vendored sampler

- `3pty/vllm/vllm/v1/sample/sampler.py`, `Sampler`: documented operation order;
  `apply_temperature` divides logits by temperature, while `sample` handles the
  greedy shortcut and calls the filtering/sampling provider.
- `3pty/vllm/vllm/model_executor/layers/utils.py`, `apply_penalties`: presence
  subtracts a fixed amount for IDs already in the output; frequency subtracts
  an amount per occurrence. Repetition penalty also considers prompt tokens.
- `3pty/vllm/vllm/v1/sample/ops/topk_topp_sampler.py`,
  `apply_top_k_top_p_pytorch`: masks low-scoring tokens with negative infinity,
  applying top-k before computing probabilities for top-p. Its ascending sort
  removes the low-probability tail while always retaining at least one token.
- In the same file, `forward_native` computes softmax over survivors, and
  `random_sample` draws with exponential noise. `flashinfer_sample` dispatches
  the optimized equivalent; it explicitly promises statistical equivalence,
  not identical sampled IDs. The vendored checkout may differ from the pinned
  container version, which is recorded with the captured data.

For example, probabilities `[0.50, 0.30, 0.15, 0.05]` become approximately
`[0.526, 0.316, 0.158, 0]` after top-k=3. Top-p=0.8 retains the first two because
their cumulative probability exceeds 0.8; renormalizing gives `[0.625, 0.375]`.
Sampling draws either token with those probabilities. Greedy always takes the
largest score instead. Lower positive temperature sharpens the distribution;
temperature zero takes the explicit greedy path rather than dividing by zero.
