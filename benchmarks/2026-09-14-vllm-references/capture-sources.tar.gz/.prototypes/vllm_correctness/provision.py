"""Fetch the official reference image and retain its immutable identity."""
import datetime
import json
from pathlib import Path
import subprocess
import tempfile

image='vllm/vllm-openai:v0.29.0'
root=Path(__file__).resolve().parents[1]
(root/'out').mkdir(exist_ok=True)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out=Path(tempfile.mkdtemp(prefix=f'vllm-pin-{stamp}-',dir=root/'out'))
print(f'Provisioning {image}; log {out}/pull.log',flush=True)
with (out/'pull.log').open('w') as f:
 r=subprocess.run(['docker','pull','--platform','linux/arm64',image],stdout=f,stderr=subprocess.STDOUT)
(out/'exit.json').write_text(json.dumps({'returncode':r.returncode})+'\n')
if r.returncode:
 print((out/'pull.log').read_text()[-5000:],flush=True)
 raise SystemExit(r.returncode)
meta=json.loads(subprocess.check_output(['docker','image','inspect',image]))[0]
(out/'image.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'tag':image,'id':meta['Id'],'digests':meta['RepoDigests'],'architecture':meta['Architecture'],'created':meta['Created']}),flush=True)
